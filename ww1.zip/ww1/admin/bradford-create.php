<?php 

include("../includes/init-session.php");                // Start Session
include("../includes/check-if-not-admin.php");          // Check if user is not admin

if(isset($_POST['create']))
{
    include("../includes/db-connection.php"); // Database connection

    // Form inputs
    $Surname = $_POST['Surname'];
    $Forename = $_POST['Forename'];
    $Address = $_POST['Address'];
    $Electoral_Ward = $_POST['Electoral_Ward'];
    $Town = $_POST['Town'];
    $Rank = $_POST['Rank'];
    $Regiment = $_POST['Regiment'];
    $Unit = $_POST['Unit'];
    $Company = $_POST['Company'];
    $Age = $_POST['Age'];
    $Service_No = $_POST['Service_No'];
    $Other_Regiment = $_POST['Other_Regiment'];
    $Other_Unit = $_POST['Other_Unit'];
    $Other_Service_No = $_POST['Other_Service_No'];
    $Medals = $_POST['Medals'];
    $Enlistment_date = $_POST['Enlistment_date'];
    $Discharge_date = $_POST['Discharge_date'];
    $Death_in_service_date = $_POST['Death_in_service_date'];
    $Misc_Info_Nroh = $_POST['Misc_Info_Nroh'];
    $Cemetery_Memorial = $_POST['Cemetery_Memorial'];
    $Cemetery_Memorial_Ref = $_POST['Cemetery_Memorial_Ref'];
    $Cemetery_Memorial_Country = $_POST['Cemetery_Memorial_Country'];
    $Additional_CWGC_info = $_POST['Additional_CWGC_info'];

    // SQL query to insert a new Bradford record
    $sql = "INSERT INTO bradford_and_surrounding_townships_great_war_roll_of_honour_2025 
        (Surname, Forename, Address, `Electoral Ward`, Town, Rank, Regiment, Unit, Company, Age, `Service No`, `Other Regiment`, `Other Unit`, `Other Service No.`, Medals, `Enlistment date`, `Discharge date`, `Death (in service) date`, `Misc Info Nroh`, `Cemetery/Memorial`, `Cemetery/Memorial Ref`, `Cemetery/Memorial Country`, `Additional CWGC info`) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssssssssssssssssssssss", 
        $Surname, $Forename, $Address, $Electoral_Ward, $Town, $Rank, $Regiment, $Unit, $Company, $Age, $Service_No, $Other_Regiment, $Other_Unit, $Other_Service_No, $Medals, $Enlistment_date, $Discharge_date, $Death_in_service_date, $Misc_Info_Nroh, $Cemetery_Memorial, $Cemetery_Memorial_Ref, $Cemetery_Memorial_Country, $Additional_CWGC_info
    );

    if ($stmt->execute()) 
    {
        $_SESSION['success'] = "Bradford created successfully!";
        header("location: bradfords.php"); 
        exit();
    }
    else
    {
        $_SESSION['error'] = "Something went wrong!";
    }

    // Redirects to bradford-create page if something goes wrong.
    header("location: bradford-create.php"); 
    exit();
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Add Bradford</title>
    <?php include("../includes/head-contents.php"); ?>
</head>
<body>

    <?php include("navbar.php"); ?>

    <div class="container my-5">
        <div class="row justify-content-center">
            <div class="box">
                <?php include("../includes/messages.php"); ?>
                <form action="bradford-create.php" method="POST">
                    <h3 class="fw-bold text-center">Add Bradford Record</h3>
                    <hr>
                    <div class="row">
                        <div class="col-md-4 my-2">
                            <label>Surname</label>
                            <input type="text" class="form-control" name="Surname" required>
                        </div>
                        <div class="col-md-4 my-2">
                            <label>Forename</label>
                            <input type="text" class="form-control" name="Forename" required>
                        </div>
                        <div class="col-md-4 my-2">
                            <label>Address</label>
                            <input type="text" class="form-control" name="Address">
                        </div>
                        <div class="col-md-4 my-2">
                            <label>Electoral Ward</label>
                            <input type="text" class="form-control" name="Electoral_Ward">
                        </div>
                        <div class="col-md-4 my-2">
                            <label>Town</label>
                            <input type="text" class="form-control" name="Town">
                        </div>
                        <div class="col-md-4 my-2">
                            <label>Rank</label>
                            <input type="text" class="form-control" name="Rank">
                        </div>
                        <div class="col-md-4 my-2">
                            <label>Regiment</label>
                            <input type="text" class="form-control" name="Regiment">
                        </div>
                        <div class="col-md-4 my-2">
                            <label>Unit</label>
                            <input type="text" class="form-control" name="Unit">
                        </div>
                        <div class="col-md-4 my-2">
                            <label>Company</label>
                            <input type="text" class="form-control" name="Company">
                        </div>
                        <div class="col-md-4 my-2">
                            <label>Age</label>
                            <input type="text" class="form-control" name="Age">
                        </div>
                        <div class="col-md-4 my-2">
                            <label>Service No</label>
                            <input type="text" class="form-control" name="Service_No">
                        </div>
                        <div class="col-md-4 my-2">
                            <label>Other Regiment</label>
                            <input type="text" class="form-control" name="Other_Regiment">
                        </div>
                        <div class="col-md-4 my-2">
                            <label>Other Unit</label>
                            <input type="text" class="form-control" name="Other_Unit">
                        </div>
                        <div class="col-md-4 my-2">
                            <label>Other Service No.</label>
                            <input type="text" class="form-control" name="Other_Service_No">
                        </div>
                        <div class="col-md-4 my-2">
                            <label>Medals</label>
                            <input type="text" class="form-control" name="Medals">
                        </div>
                        <div class="col-md-4 my-2">
                            <label>Enlistment Date</label>
                            <input type="text" class="form-control" name="Enlistment_date">
                        </div>
                        <div class="col-md-4 my-2">
                            <label>Discharge Date</label>
                            <input type="text" class="form-control" name="Discharge_date">
                        </div>
                        <div class="col-md-4 my-2">
                            <label>Death (in service) Date</label>
                            <input type="text" class="form-control" name="Death_in_service_date">
                        </div>
                        <div class="col-md-4 my-2">
                            <label>Cemetery/Memorial</label>
                            <input type="text" class="form-control" name="Cemetery_Memorial">
                        </div>
                        <div class="col-md-4 my-2">
                            <label>Cemetery/Memorial Ref</label>
                            <input type="text" class="form-control" name="Cemetery_Memorial_Ref">
                        </div>
                        <div class="col-md-4 my-2">
                            <label>Cemetery/Memorial Country</label>
                            <input type="text" class="form-control" name="Cemetery_Memorial_Country">
                        </div>
                        <div class="col-md-6 my-2">
                            <label>Misc Info Nroh</label>
                            <textarea class="form-control" name="Misc_Info_Nroh"></textarea>
                        </div>
                        <div class="col-md-6 my-2">
                            <label>Additional CWGC Info</label>
                            <textarea class="form-control" name="Additional_CWGC_info"></textarea>
                        </div>
                        <div class="col-md-12 my-2 text-center">
                            <input type="submit" class="btn btn-lg btn-danger w-50" name="create" value="Add">
                        </div>
                    </div>
                </form>

            </div>
        </div>
    </div>

    <?php include("../includes/footer.php"); ?>
    <script src="../js/preview-image.js"></script>
    
</body>
</html>