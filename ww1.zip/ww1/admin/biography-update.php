<?php 

include("../includes/init-session.php");                // Start Session
include("../includes/check-if-not-admin.php");          // Check if user is not admin
include("../includes/db-connection.php");               // Database connection

if(isset($_POST['update']))
{
    // Form inputs
    $id = $_POST['id'];
    $Surname = $_POST['Surname'];
    $Forename = $_POST['Forename'];
    $Regiment = $_POST['Regiment'];
    $Service_No = $_POST['Service_No'];
    $Attachment = $_POST['Attachment'];

    // SQL query to update biography record
    $sql = "UPDATE biography_spreadsheet 
            SET Surname = ?, Forename = ?, Regiment = ?, `Service Number` = ?, `Biography attachment` = ?
            WHERE id = ?";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssssi", 
        $Surname, $Forename, $Regiment, $Service_No, $Attachment, $id
    );

    if ($stmt->execute()) 
    {
        $_SESSION['success'] = "biography record updated successfully!";
        header("location: biographies.php"); exit();
    }
    else
    {
        $_SESSION['error'] = "Something went wrong!";
    }

    // Redirects to the same page if something goes wrong.
    header("location: biography-update.php?id=$id"); exit();
}

// Validate and sanitize input
if (isset($_GET['id']) && filter_var($_GET['id'], FILTER_VALIDATE_INT))  
{
    $biographyId = (int) $_GET['id'];

    // Fetch existing biography record
    $sql = "SELECT * FROM biography_spreadsheet WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $biographyId);
    $stmt->execute();
    $result = $stmt->get_result();

    if($result->num_rows == 0)
    {
        $_SESSION["error"] = "biography record not found!";
        header("location: biographies.php"); exit();
    }
    $biography = $result->fetch_assoc();
}
else
{
    $_SESSION["error"] = "Invalid biography ID!";
    header("location: biographies.php"); exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Edit Biography</title>
    <?php include("../includes/head-contents.php"); ?>
</head>
<body>

    <?php include("navbar.php"); ?>

    <div class="container my-5">
        <div class="row justify-content-center">
            <div class="box">
                <?php include("../includes/messages.php"); ?>
                <form action="biography-update.php" method="POST">
                    <h3 class="fw-bold text-center">Edit Biography Record</h3>
                    <hr>
                    <div class="row">
                        <div class="col-md-4 my-2">
                            <label>Surname</label>
                            <input type="hidden" class="form-control" name="id" value="<?php echo $biography['id'] ?>" required>
                            <input type="text" class="form-control" name="Surname" value="<?php echo $biography['Surname'] ?>" required>
                        </div>
                        <div class="col-md-4 my-2">
                            <label>Forename</label>
                            <input type="text" class="form-control" name="Forename" value="<?php echo $biography['Forename'] ?>" required>
                        </div>
                        <div class="col-md-4 my-2">
                            <label>Regiment</label>
                            <input type="text" class="form-control" name="Regiment" value="<?php echo $biography['Regiment'] ?>">
                        </div>
                        <div class="col-md-6 my-2">
                            <label>Service No</label>
                            <input type="text" class="form-control" name="Service_No" value="<?php echo $biography['Service Number'] ?>">
                        </div>
                        <div class="col-md-6 my-2">
                            <label>Biography Attachment</label>
                            <input type="text" class="form-control" name="Attachment" value="<?php echo $biography['Biography attachment'] ?>">
                        </div>
                        <div class="col-md-12 my-2 text-center">
                            <input type="submit" class="btn btn-lg btn-danger w-50" name="update" value="Update">
                        </div>
                    </div>
                </form>

            </div>
        </div>
    </div>

    <?php include("../includes/footer.php"); ?>
    
</body>
</html>
