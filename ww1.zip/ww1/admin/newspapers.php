<?php 

include("../includes/init-session.php");                // Start Session
include("../includes/check-if-not-admin.php");          // Check if user is not admin
include("../includes/db-connection.php");               // Database connection

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Newspaper Ref</title>
    <?php include("../includes/head-contents.php"); ?>
</head>
<body>

    <?php include("navbar.php"); ?>
    <?php include("../includes/messages.php"); ?>

    <div class="container mt-1 mb-5">
        <div class="row">
            <div class="box">
                <div class="row">
                    <div class="col-8">
                        <h3 class="fw-bold my-0">Newspaper Ref</h3>
                    </div>
                    <div class="col-4 text-end">
                        <a href="newspaper-create.php" class="btn btn-outline-danger">Add Newspaper Ref</a>
                    </div>
                </div>
                <hr>
                <div class="table-responsive crud-table">
                <?php 
                // Sql query to get all biographies
                $sql = "SELECT * FROM newspaper_references_2025 ORDER BY id DESC LIMIT 20";
                $stmt = $conn->prepare($sql);
                $stmt->execute();
                $result = $stmt->get_result();
                if($result->num_rows > 0) { ?>
                <table class="table table-striped">
                    <tr class="sticky-header">
                        <th>#</th>
                        <th>Surname</th>
                        <th>Forename</th>
                        <th>Rank</th>
                        <th>Address</th>
                        <th>Regiment</th>
                        <th>Unit</th>
                        <th>Article Comment</th>
                        <th>Newspaper Name</th>
                        <th>Newspaper Date</th>
                        <th>Page/Col</th>
                        <th>Photo incl</th>
                        <th>Action</th>
                    </tr>
                    <?php $i = 1; while ($newspaper = $result->fetch_assoc()) { ?>
                    <tr>
                        <td><?php echo $i++; ?></td>
                        <td><?php echo htmlspecialchars($newspaper['Surname']); ?></td>
                        <td><?php echo htmlspecialchars($newspaper['Forename']); ?></td>
                        <td><?php echo htmlspecialchars($newspaper['Rank']); ?></td>
                        <td><?php echo htmlspecialchars($newspaper['Address']); ?></td>
                        <td><?php echo htmlspecialchars($newspaper['Regiment']); ?></td>
                        <td><?php echo htmlspecialchars($newspaper['Unit']); ?></td>
                        <td><?php echo htmlspecialchars($newspaper['Article Comment']); ?></td>
                        <td><?php echo htmlspecialchars($newspaper['Newspaper Name']); ?></td>
                        <td><?php echo htmlspecialchars($newspaper['Newspaper Date']); ?></td>
                        <td><?php echo htmlspecialchars($newspaper['Page/Col']); ?></td>
                        <td><?php echo htmlspecialchars($newspaper['Photo incl']); ?></td>
                        <td class="action-column">
                            <a href="newspaper-view.php?id=<?php echo $newspaper['id']; ?>" class="btn btn-warning btn-sm my-1" title="View">
                                <i class="fa fa-eye"></i>
                            </a>
                            <a href="newspaper-update.php?id=<?php echo $newspaper['id']; ?>" class="btn btn-success btn-sm my-1" title="Edit">
                                <i class="fa fa-pencil"></i>
                            </a>
                            <form action="newspaper-delete.php" method="POST" class="d-inline-block my-1">
                                <input type="hidden" name="id" value="<?php echo $newspaper['id']; ?>">
                                <button type="submit" name="delete" class="btn btn-trash btn-sm" title="Delete" onclick="return confirm('Are you sure you want to remove this record?');">
                                    <i class="fa fa-trash"></i>
                                </button>
                            </form>
                        </td>
                    </tr>
                    <?php } ?> 
                </table>
                <?php } else { ?>
                    <span class="fw-bold">No record found!</span>
                <?php } ?>
    
                </div>
            </div>
        </div>
    </div>

    <?php include("../includes/footer.php"); ?>
    
</body>
</html>