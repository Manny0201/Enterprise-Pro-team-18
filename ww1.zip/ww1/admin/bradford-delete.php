<?php 

include("../includes/init-session.php");                // Start Session
include("../includes/check-if-not-admin.php");          // Check if user is not admin
include("../includes/db-connection.php");               // Database connection

// Validate and sanitize input
if (isset($_POST['id']) && filter_var($_POST['id'], FILTER_VALIDATE_INT))  
{
    // Ensure the ID is an integer
    $bradfordId = (int) $_POST['id'];

    // SQL statement to delete
    $sql = "DELETE FROM bradford_and_surrounding_townships_great_war_roll_of_honour_2025 WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $bradfordId);
    $stmt->execute();
    
    // Set success message
    $_SESSION["success"] = "Bradford deleted successfully!";
}
else
{
    // Set error message
    $_SESSION["error"] = "Invalid bradford ID!";
}

// Redirect to bradfords page
header("location: bradfords.php"); exit();
?>