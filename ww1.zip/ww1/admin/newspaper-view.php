<?php 

include("../includes/init-session.php");                // Start Session
include("../includes/check-if-not-admin.php");          // Check if user is not admin
include("../includes/db-connection.php");               // Database connection

// Validate and sanitize input
if (isset($_GET['id']) && filter_var($_GET['id'], FILTER_VALIDATE_INT))  
{
    // Ensure the ID is an integer
    $newspaperId = (int) $_GET['id'];

    // SQL statement to get newspaper record
    $sql = "SELECT * FROM newspaper_references_2025 WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $newspaperId);
    $stmt->execute();
    $result = $stmt->get_result();

    if($result->num_rows == 0)
    {
        $_SESSION["error"] = "Newspaper Ref not found!";
        header("location: newspapers.php"); exit();      // redirects if record not found
    }
    $newspaper = $result->fetch_assoc();
}
else
{
    $_SESSION["error"] = "Invalid Newspaper ID!";
    header("location: newspapers.php"); exit();          // redirects if invalid id
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title><?php echo $newspaper['Surname'] ?> - <?php echo $newspaper['Forename'] ?></title>
    <?php include("../includes/head-contents.php"); ?>
</head>
<body>

    <?php include("navbar.php"); ?>

    <div class="container my-5">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="box">
                    <div class="row">
                        <div class="col-12">
                            <h3 class="fw-bold"><?php echo $newspaper['Surname'] ?> - <?php echo $newspaper['Forename'] ?></h3>
                            <hr>
                            <table class="table">
                                <tr>
                                    <td class="fw-bold text-secondary">Surname</td>
                                    <td><?php echo htmlspecialchars($newspaper['Surname']); ?></td>
                                </tr>
                                <tr>
                                    <td class="fw-bold text-secondary">Forename</td>
                                    <td><?php echo htmlspecialchars($newspaper['Forename']); ?></td>
                                </tr>
                                <tr>
                                    <td class="fw-bold text-secondary">Rank</td>
                                    <td><?php echo htmlspecialchars($newspaper['Rank']); ?></td>
                                </tr>
                                <tr>
                                    <td class="fw-bold text-secondary">Address</td>
                                    <td><?php echo htmlspecialchars($newspaper['Address']); ?></td>
                                </tr>
                                <tr>
                                    <td class="fw-bold text-secondary">Regiment</td>
                                    <td><?php echo htmlspecialchars($newspaper['Regiment']); ?></td>
                                </tr>
                                <tr>
                                    <td class="fw-bold text-secondary">Unit</td>
                                    <td><?php echo htmlspecialchars($newspaper['Unit']); ?></td>
                                </tr>
                                <tr>
                                    <td class="fw-bold text-secondary">Article Comment</td>
                                    <td><?php echo htmlspecialchars($newspaper['Article Comment']); ?></td>
                                </tr>
                                <tr>
                                    <td class="fw-bold text-secondary">Newspaper Name</td>
                                    <td><?php echo htmlspecialchars($newspaper['Newspaper Name']); ?></td>
                                </tr>
                                <tr>
                                    <td class="fw-bold text-secondary">Newspaper Date</td>
                                    <td><?php echo htmlspecialchars($newspaper['Newspaper Date']); ?></td>
                                </tr>
                                <tr>
                                    <td class="fw-bold text-secondary">Page/Col</td>
                                    <td><?php echo htmlspecialchars($newspaper['Page/Col']); ?></td>
                                </tr>
                                <tr>
                                    <td class="fw-bold text-secondary">Photo incl</td>
                                    <td><?php echo htmlspecialchars($newspaper['Photo incl']); ?></td>
                                </tr>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php include("../includes/footer.php"); ?>
</body>
</html>