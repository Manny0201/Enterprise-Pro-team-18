<?php 

include("../includes/init-session.php");                // Start Session
include("../includes/check-if-not-admin.php");          // Check if user is not admin
include("../includes/db-connection.php");               // Database connection

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Bradfords</title>
    <?php include("../includes/head-contents.php"); ?>
</head>
<body>

    <?php include("navbar.php"); ?>
    <?php include("../includes/messages.php"); ?>

    <div class="container mt-1 mb-5">
        <div class="row">
            <div class="box">
                <div class="row">
                    <div class="col-8">
                        <h3 class="fw-bold my-0">Bradfords</h3>
                    </div>
                    <div class="col-4 text-end">
                        <a href="bradford-create.php" class="btn btn-outline-danger">Add Bradford</a>
                    </div>
                </div>
                <hr>
                <div class="table-responsive crud-table">
                <?php 
                // Sql query to get all bradfords
                $sql = "SELECT * FROM bradford_and_surrounding_townships_great_war_roll_of_honour_2025 ORDER BY id DESC LIMIT 20";
                $stmt = $conn->prepare($sql);
                $stmt->execute();
                $result = $stmt->get_result();
                if($result->num_rows > 0) { ?>
                    <table class="table table-striped">
                        <tr class="sticky-header">
                            <th>#</th>
                            <th>Surname</th>
                            <th>Forename</th>
                            <th>Address</th>
                            <th>Electoral Ward</th>
                            <th>Town</th>
                            <th>Rank</th>
                            <th>Regiment</th>
                            <th>Unit</th>
                            <th>Company</th>
                            <th>Age</th>
                            <th>Service No</th>
                            <th>Other Regiment</th>
                            <th>Other Unit</th>
                            <th>Other Service No.</th>
                            <th>Medals</th>
                            <th>Enlistment Date</th>
                            <th>Discharge Date</th>
                            <th>Death (in service) Date</th>
                            <th>Misc Info Nroh</th>
                            <th>Cemetery/Memorial</th>
                            <th>Cemetery/Memorial Ref</th>
                            <th>Cemetery/Memorial Country</th>
                            <th>Additional CWGC Info</th>
                            <th>Action</th>
                        </tr>
                        <?php $i = 1; while($bradford = $result->fetch_assoc()) { ?>
                        <tr>
                            
                            <td><?php echo $i++; ?></td>
                            <td><?php echo htmlspecialchars($bradford['Surname']); ?></td>
                            <td><?php echo htmlspecialchars($bradford['Forename']); ?></td>
                            <td><?php echo htmlspecialchars($bradford['Address']); ?></td>
                            <td><?php echo htmlspecialchars($bradford['Electoral Ward']); ?></td>
                            <td><?php echo htmlspecialchars($bradford['Town']); ?></td>
                            <td><?php echo htmlspecialchars($bradford['Rank']); ?></td>
                            <td><?php echo htmlspecialchars($bradford['Regiment']); ?></td>
                            <td><?php echo htmlspecialchars($bradford['Unit']); ?></td>
                            <td><?php echo htmlspecialchars($bradford['Company']); ?></td>
                            <td><?php echo htmlspecialchars($bradford['Age']); ?></td>
                            <td><?php echo htmlspecialchars($bradford['Service No']); ?></td>
                            <td><?php echo htmlspecialchars($bradford['Other Regiment']); ?></td>
                            <td><?php echo htmlspecialchars($bradford['Other Unit']); ?></td>
                            <td><?php echo htmlspecialchars($bradford['Other Service No.']); ?></td>
                            <td><?php echo htmlspecialchars($bradford['Medals']); ?></td>
                            <td><?php echo htmlspecialchars($bradford['Enlistment date']); ?></td>
                            <td><?php echo htmlspecialchars($bradford['Discharge date']); ?></td>
                            <td><?php echo htmlspecialchars($bradford['Death (in service) date']); ?></td>
                            <td><?php echo htmlspecialchars($bradford['Misc Info Nroh']); ?></td>
                            <td><?php echo htmlspecialchars($bradford['Cemetery/Memorial']); ?></td>
                            <td><?php echo htmlspecialchars($bradford['Cemetery/Memorial Ref']); ?></td>
                            <td><?php echo htmlspecialchars($bradford['Cemetery/Memorial Country']); ?></td>
                            <td><?php echo htmlspecialchars($bradford['Additional CWGC info']); ?></td>
                            <td class="action-column">
                                <a href="bradford-view.php?id=<?php echo $bradford['id'] ?>" class="btn btn-warning btn-sm my-1" title="View"><i class="fa fa-eye"></i></a>
                                <a href="bradford-update.php?id=<?php echo $bradford['id'] ?>" class="btn btn-success btn-sm my-1" title="Edit"><i class="fa fa-pencil"></i></a>
                                <form action="bradford-delete.php" method="POST" class="d-inline-block my-1">
                                    <input type="hidden" name="id" value="<?php echo $bradford['id'] ?>">
                                    <button type="submit" name="delete" class="btn btn-trash btn-sm" title="Delete" onclick="return confirm('Are you sure you want to remove this record?');"><i class="fa fa-trash"></i></button>
                                </form>
                            </td>
                        </tr>
                        <?php } ?> 
                    </table>
                <?php } else { ?>
                    <span class="fw-bold">No record found!</span>
                <?php } ?>
    
                </div>
            </div>
        </div>
    </div>

    <?php include("../includes/footer.php"); ?>
    
</body>
</html>