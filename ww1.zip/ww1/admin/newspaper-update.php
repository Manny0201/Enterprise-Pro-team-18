<?php 

include("../includes/init-session.php");                // Start Session
include("../includes/check-if-not-admin.php");          // Check if user is not admin
include("../includes/db-connection.php");               // Database connection

if (isset($_POST['update'])) {
    // Form inputs
    $id = $_POST['id'];
    $Surname = $_POST['Surname'];
    $Forename = $_POST['Forename'];
    $Rank = $_POST['Rank'];
    $Address = $_POST['Address'];
    $Regiment = $_POST['Regiment'];
    $Unit = $_POST['Unit'];
    $ArticleComment = $_POST['Article_Comment'];
    $NewspaperName = $_POST['Newspaper_Name'];
    $NewspaperDate = $_POST['Newspaper_Date'];
    $PageCol = $_POST['Page/Col'];
    $PhotoIncl = $_POST['Photo_incl'];

    // SQL query to update newspaper record
    $sql = "UPDATE newspaper_references_2025 
            SET Surname = ?, Forename = ?, Rank = ?, Address = ?, Regiment = ?, Unit = ?, 
                `Article Comment` = ?, `Newspaper Name` = ?, `Newspaper Date` = ?, `Page/Col` = ?, `Photo incl` = ? 
            WHERE id = ?";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssssssssssi", 
        $Surname, $Forename, $Rank, $Address, $Regiment, $Unit, $ArticleComment, $NewspaperName, $NewspaperDate, $PageCol, $PhotoIncl, $id
    );

    if ($stmt->execute()) {
        $_SESSION['success'] = "Newspaper Ref updated successfully!";
        header("location: newspapers.php"); 
        exit();
    } else {
        $_SESSION['error'] = "Something went wrong!";
    }

    // Redirects to the same page if something goes wrong.
    header("location: newspaper-update.php?id=$id"); 
    exit();
}


// Validate and sanitize input
if (isset($_GET['id']) && filter_var($_GET['id'], FILTER_VALIDATE_INT))  
{
    $newspaperId = (int) $_GET['id'];

    // Fetch existing newspaper record
    $sql = "SELECT * FROM newspaper_references_2025 WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $newspaperId);
    $stmt->execute();
    $result = $stmt->get_result();

    if($result->num_rows == 0)
    {
        $_SESSION["error"] = "newspaper Ref not found!";
        header("location: newspapers.php"); exit();
    }
    $newspaper = $result->fetch_assoc();
}
else
{
    $_SESSION["error"] = "Invalid newspaper ID!";
    header("location: newspapers.php"); exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Edit Newspaper Ref</title>
    <?php include("../includes/head-contents.php"); ?>
</head>
<body>

    <?php include("navbar.php"); ?>

    <div class="container my-5">
        <div class="row justify-content-center">
            <div class="box">
                <?php include("../includes/messages.php"); ?>
                <form action="newspaper-update.php" method="POST">
                    <h3 class="fw-bold text-center">Edit Newspaper Ref</h3>
                    <hr>
                    <div class="row">
                        <div class="col-md-4 my-2">
                            <label>Surname</label>
                            <input type="hidden" class="form-control" name="id" value="<?php echo $newspaper['id'] ?>" required>
                            <input type="text" class="form-control" name="Surname" value="<?php echo $newspaper['Surname'] ?>" required>
                        </div>
                        <div class="col-md-4 my-2">
                            <label>Forename</label>
                            <input type="text" class="form-control" name="Forename" value="<?php echo $newspaper['Forename'] ?>" required>
                        </div>
                        <div class="col-md-4 my-2">
                            <label>Rank</label>
                            <input type="text" class="form-control" name="Rank" value="<?php echo $newspaper['Rank'] ?>">
                        </div>
                        <div class="col-md-4 my-2">
                            <label>Address</label>
                            <input type="text" class="form-control" name="Address" value="<?php echo $newspaper['Address'] ?>">
                        </div>
                        <div class="col-md-4 my-2">
                            <label>Regiment</label>
                            <input type="text" class="form-control" name="Regiment" value="<?php echo $newspaper['Regiment'] ?>">
                        </div>
                        <div class="col-md-4 my-2">
                            <label>Unit</label>
                            <input type="text" class="form-control" name="Unit" value="<?php echo $newspaper['Unit'] ?>">
                        </div>
                        <div class="col-md-4 my-2">
                            <label>Article Comment</label>
                            <input type="text" class="form-control" name="Article_Comment" value="<?php echo $newspaper['Article Comment'] ?>">
                        </div>
                        <div class="col-md-4 my-2">
                            <label>Newspaper Name</label>
                            <input type="text" class="form-control" name="Newspaper_Name" value="<?php echo $newspaper['Newspaper Name'] ?>">
                        </div>
                        <div class="col-md-4 my-2">
                            <label>Newspaper Date</label>
                            <input type="text" class="form-control" name="Newspaper_Date" value="<?php echo $newspaper['Newspaper Date'] ?>">
                        </div>
                        <div class="col-md-6 my-2">
                            <label>Page/Col</label>
                            <input type="text" class="form-control" name="Page/Col" value="<?php echo $newspaper['Page/Col'] ?>">
                        </div>
                        <div class="col-md-6 my-2">
                            <label>Photo incl</label>
                            <select name="Photo_incl" class="form-control">
                                <option value="No" <?php echo ($newspaper['Photo incl'] == "No") ? "selected" : "" ?>>No</option>
                                <option value="Yes" <?php echo ($newspaper['Photo incl'] == "Yes") ? "selected" : "" ?>>Yes</option>
                            </select>
                        </div>
                        <div class="col-md-12 my-2 text-center">
                            <input type="submit" class="btn btn-lg btn-danger w-50" name="update" value="Update">
                        </div>
                    </div>
                </form>

            </div>
        </div>
    </div>

    <?php include("../includes/footer.php"); ?>
    
</body>
</html>
