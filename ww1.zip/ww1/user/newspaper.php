<?php 

include("../includes/init-session.php");                // Start Session
include("../includes/check-if-not-user.php");           // Check if not user
include("../includes/db-connection.php");               // Database connection
$where = '';
if (isset($_GET['submit']) && $_GET['submit'] != '') 
{
    $name = $_GET['search'];
    $where = "WHERE Surname LIKE '%$name%' OR Forename LIKE '%$name%'";
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>People Search | Bradford in World War 1</title>
    <?php include("../includes/head-contents.php"); ?>
    <style>
        /* Copying exact shared styles from About Us */
        body {
            font-family: 'Georgia', serif;
            margin: 0;
            padding: 0;
            line-height: 1.8;
            color: #333;
            background: #f9f9f9;
            scroll-behavior: smooth;
            overflow-x: hidden;
        }

        h1, h2, h3 {
            margin: 0;
            font-weight: bold;
        }

        a {
            text-decoration: none;
            color: inherit;
        }

        .container {
            width: 90%;
            margin: 0 auto;
            max-width: 1200px;
        }

        header {
            background: #1d4634;
            padding: 20px 0;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            position: fixed;
            width: 100%;
            top: 0;
            z-index: 1000;
            animation: fadeIn 1s ease-in-out;
        }

        .logo {
            width: 150px;
            height: auto;
        }

        nav {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        nav ul {
            list-style: none;
            margin: 0;
            padding: 0;
            display: flex;
            gap: 20px;
        }

        nav ul li a {
            color: #fff;
            font-weight: bold;
            padding: 10px 15px;
            border-radius: 5px;
            transition: background 0.3s ease, transform 0.2s ease;
        }

        nav ul li a:hover {
            background: #3a763a;
            transform: scale(1.05);
        }

        .search-bar {
            display: flex;
            align-items: center;
            background: white;
            border-radius: 20px;
            padding: 5px 10px;
        }

        .search-bar input {
            border: none;
            padding: 8px;
            outline: none;
            border-radius: 15px;
        }

        /* Animation */
        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }

        /* Page content fade-in effect */
        .fade-in-section {
            opacity: 0;
            animation: fadeIn 2s forwards;
            animation-delay: 0.5s; /* Ensure this matches the exact delay you need */
        }

        .fade-in-section.loaded {
            opacity: 1;
        }

        .about-section {
            padding: 120px 0 60px;
            background-color: #f4f4f4;
            text-align: center;
            color: #333;
            animation: fadeIn 1.5s ease-in-out;
        }

        .about-section h2 {
            font-size: 2.8rem;
            margin-bottom: 20px;
            color: #3a763a;
            font-weight: bold;
        }

        .about-description {
            font-size: 1.2rem;
            margin-bottom: 40px;
            color: #555;
            line-height: 1.6;
            max-width: 900px;
            margin-left: auto;
            margin-right: auto;
        }

        form.search-form {
            margin-top: 40px;
            max-width: 600px;
            margin-left: auto;
            margin-right: auto;
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
            justify-content: center;
        }

        form.search-form input {
            flex: 1;
            padding: 12px;
            border-radius: 8px;
            border: 1px solid #ccc;
            font-size: 1rem;
            min-width: 250px;
        }

        form.search-form button {
            padding: 12px 20px;
            background-color: #4a6b5c;
            color: white;
            border: none;
            border-radius: 5px;
            font-size: 1rem;
            cursor: pointer;
            transition: background 0.3s ease, transform 0.3s ease;
        }

        form.search-form button:hover {
            background-color: #6b8e23;
            transform: scale(1.05);
        }

        footer {
            background: #2c4c3b;
            color: #fff;
            text-align: center;
            padding: 40px 0;
            animation: fadeIn 2s ease-in-out;
        }

        footer p {
            margin: 0;
            font-size: 1rem;
        }

        .fade-in-image {
            opacity: 0;
            transition: opacity 2s ease-in-out;
        }

        .fade-in-image.loaded {
            opacity: 1;
        }

        @media (max-width: 768px) {
            nav ul {
                flex-direction: column;
                gap: 10px;
            }

            form.search-form {
                flex-direction: column;
            }
        }

        b {
            min-height: 100vh;
            position: relative;
            margin: 0;
            padding-bottom: 100px;
            box-sizing: border-box;
            background-color: var(--bodyBackgroundColor);
        }


        .box {
            box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
            padding: 20px;
            border-radius: 20px;
            background-color: #ffffff;
        }

        hr {
            border: 1.5px solid var(--mainColor);
            opacity: 75%;
        }

        .form-control:focus {
            border-color: var(--formControlFocusBorderColor) !important;
            box-
            shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075), 0 0 8px var(--formControlFocusShadowColor) !important;
        }
        .btn-danger, .btn-danger:focus {
            background-color: var(--mainColor) !important;
            border-color: var(--mainColor) !important;
        }

        .btn-outline-danger {
            border-color: var(--mainColor) !important;
        }

        .btn-danger:hover, .btn-outline-danger:hover {
            background-color: var(--buttonHoverColor) !important;
            border-color: var(--buttonHoverColor) !important;
            color: #ffffff !important;
        }

        .text-danger, .btn-outline-danger {
            color: var(--mainColor) !important;
        }

        .table-responsive {
            max-height: 550px !important;
        }
        .table-responsive th {
            position: sticky;
            top: 0;
            z-index: 999;
        }

    </style>
</head>
<body>

    <header>
        <div class="container">
            <nav>
                <img src="BradfordWW1.png" alt="Bradford WW1 Logo" class="logo">
                <ul>
                    <li><a href="homepage.html">Home</a></li>
                    <li><a href="peoplesearch.html">People Search</a></li>
                    <li><a href="aboutus.html">About</a></li>
                    <li><a href="contact.html">Contact</a></li>
                </ul>
                <div class="search-bar">
                    <input type="text" placeholder="Search...">
                </div>
            </nav>
        </div>
    </header>

    <!-- People Search Section -->
    <section class="about-section fade-in-section">
        <div class="container">
            <h2>Newspaper References</h2>
            <p class="about-description">
                Search for individuals from Bradford who served during World War 1. Enter a name below.
            </p>

            <!-- New Image with fade-in effect -->
            <img src="bradford_ww1_council.jpg" alt="Bradford WW1 Council" class="fade-in-image" id="fadeImage" style="width: 100%; height: auto; border-radius: 10px; margin-bottom: 40px;">


        </div>
    </section>
</body>

<b>
    <div class="container my-5">
        <div class="box">
            <div class="row">
                <?php include("../includes/messages.php"); ?>
                <form action="newspaper.php" method="GET">
                    <div class="row mb-5">
                        <div class="col-9">
                            <input type="text" class="form-control" name="search" placeholder="Search Surname or Forename here" required>
                        </div>
                        <div class="col-3">
                            <input type="submit" class="btn btn-danger w-100" name="submit" value="Search">
                        </div>
                    </div>
                </form>
            </div>
            <h2 class="fw-bold">Bradford and Surrounding Townships</h2>
            <hr>
            <div class="table-responsive">
                <table class="table table-striped table-sm">
                    <tr>
                        <th>Surname</th> 
                        <th>Forename</th> 
                        <th>Rank</th> 
                        <th>Address</th> 
                        <th>Regiment</th> 
                        <th>Unit</th> 
                        <th>Article Comment</th> 
                        <th>Newspaper Name</th> 
                        <th>Newspaper Date</th> 
                        <th>Page/Col</th> 
                        <th>Photo incl</th> 
                    </tr>
                    <?php
                        $sql = "SELECT * FROM newspaper_references_2025 $where LIMIT 10";
                        $result = $conn-> query($sql); 
                        if($result-> num_rows > 0) {
                        while($row = $result-> fetch_assoc()) { ?>
                            <tr>
                                <td><?php echo $row["Surname"]; ?></td>
                                <td><?php echo $row["Forename"]; ?></td>
                                <td><?php echo $row["Rank"]; ?></td>
                                <td><?php echo $row["Address"]; ?></td>
                                <td><?php echo $row["Regiment"]; ?></td>
                                <td><?php echo $row["Unit"]; ?></td>
                                <td><?php echo $row["Article Comment"]; ?></td>
                                <td><?php echo $row["Newspaper Name"]; ?></td>
                                <td><?php echo $row["Newspaper Date"]; ?></td>
                                <td><?php echo $row["Page/Col"]; ?></td>
                                <td><?php echo $row["Photo incl"]; ?></td>
                            </tr>
                            <?php }} ?>
                </table>
            </div>
        </div>
    </div>
    
 </b>

<body>
    <!-- Footer -->
    <footer>
        <p>&copy; 2025 Bradford in World War 1 | All Rights Reserved</p>
    </footer>

    <script>
        // Ensure the image is fully loaded before applying the fade-in effect
        const image = document.getElementById('fadeImage');
        image.onload = function() {
            image.classList.add('loaded');
        };

        // Ensure the page content also fades in once it's loaded
        window.addEventListener('load', function() {
            const section = document.querySelector('.fade-in-section');
            section.classList.add('loaded');
        });
    </script>

</body>
</html>
