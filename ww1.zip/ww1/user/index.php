<?php 

include("../includes/init-session.php");                // Start Session
include("../includes/check-if-not-user.php");           // Check if not user
include("../includes/db-connection.php");               // Database connection
$where = '';
if (isset($_GET['submit']) && $_GET['submit'] != '') 
{
    $name = $_GET['search'];
    $where = "WHERE Surname LIKE '%$name%' OR Forename LIKE '%$name%'";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>People Search</title>
    <?php include("../includes/head-contents.php"); ?>
    <style>
        .table-responsive
        {
            max-height: 550px !important;
        }
        .table-responsive th
        {
            position: sticky;
            top: 0;
            z-index: 999;
        }
    </style>
</head>
<body>

    <?php include("../includes/navbar.php"); ?>

    <div class="container my-5">
        <div class="box">
            <div class="row">
                <?php include("../includes/messages.php"); ?>
                <form action="index.php" method="GET">
                    <div class="row mb-5">
                        <div class="col-9">
                            <input type="text" class="form-control" name="search" placeholder="Search Surname or Forename here" required>
                        </div>
                        <div class="col-3">
                            <input type="submit" class="btn btn-danger w-100" name="submit" value="Search">
                        </div>
                    </div>
                </form>
            </div>
            <h2 class="fw-bold">Bradford and Surrounding Townships</h2>
            <hr>
            <div class="table-responsive">
                <table class="table table-striped table-sm">
                    <tr>
                        <th>Surname</th> 
                        <th>Forename</th> 
                        <th>Address</th> 
                        <th>Electoral Ward</th> 
                        <th>Town</th> 
                        <th>Rank</th> 
                        <th>Regiment</th> 
                        <th>Unit</th> 
                        <th>Company</th> 
                        <th>Age</th> 
                        <th>Service No</th> 
                        <th>Other Regiment</th> 
                        <th>Other unit</th> 
                        <th>Other service No.</th> 
                        <th>Medals</th> 
                        <th>Enlistment date</th> 
                        <th>Discharge date</th> 
                        <th>Death (in service ) date</th> 
                        <th>Misc Info Nroh</th> 
                        <th>Cemetery/Memorial</th> 
                        <th>Cemetery/Memorial Ref</th> 
                        <th>Cemetery/Memorial Country</th> 
                        <th>Additional CWGC info</th> 
                    </tr>
                    <?php
                        $sql = "SELECT * FROM bradford_and_surrounding_townships_great_war_roll_of_honour_2025 $where LIMIT 20";
                        $result = $conn-> query($sql); 
                        if($result-> num_rows > 0) {
                        while($row = $result-> fetch_assoc()) { ?>
                            <tr>
                                <td><?php echo $row["Surname"]; ?></td>
                                <td><?php echo $row["Forename"]; ?></td>
                                <td><?php echo $row["Address"]; ?></td>
                                <td><?php echo $row["Electoral Ward"]; ?></td>
                                <td><?php echo $row["Town"]; ?></td>
                                <td><?php echo $row["Rank"]; ?></td>
                                <td><?php echo $row["Regiment"]; ?></td>
                                <td><?php echo $row["Unit"]; ?></td>
                                <td><?php echo $row["Company"]; ?></td>
                                <td><?php echo $row["Age"]; ?></td>
                                <td><?php echo $row["Service No"]; ?></td>
                                <td><?php echo $row["Other Regiment"]; ?></td>
                                <td><?php echo $row["Other Unit"]; ?></td>
                                <td><?php echo $row["Other Service No."]; ?></td>
                                <td><?php echo $row["Medals"]; ?></td>
                                <td><?php echo $row["Enlistment date"]; ?></td>
                                <td><?php echo $row["Discharge date"]; ?></td>
                                <td><?php echo $row["Death (in service) date"]; ?></td>
                                <td><?php echo $row["Misc Info Nroh"]; ?></td>
                                <td><?php echo $row["Cemetery/Memorial"]; ?></td>
                                <td><?php echo $row["Cemetery/Memorial Ref"]; ?></td>
                                <td><?php echo $row["Cemetery/Memorial Country"]; ?></td>
                                <td><?php echo $row["Additional CWGC info"]; ?></td>
                            </tr>
                            <?php }} ?>
                </table>
            </div>
        </div>
    </div>
<?php include("../includes/footer.php"); ?>
</body>
</html>