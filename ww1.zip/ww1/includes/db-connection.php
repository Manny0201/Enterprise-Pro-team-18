<?php 

/* -------------------------------------------------------------------------- */
/*                             Database Connection                            */
/* -------------------------------------------------------------------------- */


// Define constants for database connection parameters
define('DB_SERVER', 'localhost');       // Server name
define('DB_USERNAME', 'localhost');          // Database username
define('DB_PASSWORD', 'password');              // Database password (empty for no password)
define('DB_NAME', 'ww1database');   // Database name

try 
{
    // Create a new mysqli object with error handling enabled
    $conn = new mysqli(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);
} 
catch (Exception $e) 
{
    // Handle the exception and display the error message
    echo "ERROR: " . $e->getMessage(); exit();
}

?>