<!DOCTYPE html>
<html lang="en">
<head>
    <title>About</title>
    <?php include("../includes/head-contents.php"); ?>
</head>
<body>

    <?php include("../includes/navbar.php"); ?>

    <div class="container my-3">
        <div class="row">
            <div class="col-md-12 my-3">
                <div class="shadow rounded p-4">
                    <h4>Our Story</h4>
                    <p class="text-secondary">Founded in the heart of Bradford, the Bradford WW1 Memorial stands as a tribute to the men and women who sacrificed their lives during the Great War. In a city where industrial might met unwavering community spirit, our memorial is a reminder of the resilience and courage that shaped the world we live in today. Our mission is not only to honor the heroes of the past, but also to ensure their stories echo through the generations to come.</p>
                </div>
            </div>
            <div class="col-md-6 my-3">
                <div class="shadow rounded p-4">
                    <h4>Remembrance</h4>
                    <p class="text-secondary">Remembrance is more than just a day. It’s a lifelong journey. Through meticulously curated archives, personal stories, and community outreach, the Bradford WW1 Memorial brings history to life. Our purpose is to illuminate the experiences of those who served, so their bravery never fades into the past. From the trenches to the homefront, their sacrifices echo in every corner of our community.</p>
                </div>
            </div>
            <div class="col-md-6 my-3">
                <div class="shadow rounded p-4">
                    <h4>Get Involved</h4>
                    <p class="text-secondary">Honoring the past requires action in the present. Whether you're a historian, a descendant of a soldier, or someone simply seeking to understand the gravity of history, there are countless ways to contribute. Explore our online archives, attend remembrance events, and become part of a growing community dedicated to preserving the memories of those who gave everything.</p>
                </div>
            </div>
        </div>
    </div>

    <?php include("../includes/footer.php"); ?>
    
</body>
</html>