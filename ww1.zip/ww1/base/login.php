<?php 

include("../includes/init-session.php");                // Start Session
include("../includes/check-loggedin-user.php");         // Check if user is already logged in

if(isset($_POST['login']))
{
    include("../includes/db-connection.php");           // Database connection

    // Form inputs
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Data validation
    if (empty($email) || empty($password)) 
    {
        $_SESSION['error'] = "Please fill all fields!";
    } 
    else
    {
        // Sql query to check username exists in users table
        $sql = "SELECT * FROM users WHERE username = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();
        $user = $result->fetch_assoc();

        if($user)
        {
            $userId = $user['id'];
            $failedAttempts = $user['failed_attempts'];
            $lockoutTime = $user['lockout_time'];
            
            // Check if user is currently locked out
            if ($lockoutTime && strtotime($lockoutTime) > time()) 
            {
                $_SESSION['error'] = "Too many failed login attempts. Please try again after 10 minutes.";
            } 
            else 
            {
                // Verify user password
                if (password_verify($password, $user['password'])) 
                {
                    // Reset failed attempts on successful login
                    $updateSQL = "UPDATE users SET failed_attempts = 0, lockout_time = NULL WHERE id = ?";
                    $updateStmt = $conn->prepare($updateSQL);
                    $updateStmt->bind_param("i", $userId);
                    $updateStmt->execute();

                    // Store user data in SESSION variables
                    $_SESSION['loggedin'] = true;
                    $_SESSION['userId'] = $user['id'];
                    $_SESSION['username'] = $user['username'];
                    $_SESSION['userEmail'] = $user['email'];
                    $_SESSION['userRole'] = $user['role'];

                    // Redirect based on user role
                    if($user['role'] == 'a')
                    {
                        header("location: ../admin/index.php"); exit();
                    }
                    else
                    {
                        header("location: ../user/homepage.html"); exit();
                    }
                }
                else
                {
                    $failedAttempts++;

                    // If failed attempts reach 3, lock the user out for 10 minutes
                    if ($failedAttempts >= 3) 
                    {
                        $lockoutTime = date('Y-m-d H:i:s', strtotime("+10 minutes"));
                        $updateSQL = "UPDATE users SET failed_attempts = ?, lockout_time = ? WHERE id = ?";
                        $updateStmt = $conn->prepare($updateSQL);
                        $updateStmt->bind_param("isi", $failedAttempts, $lockoutTime, $userId);
                        $_SESSION['error'] = "Too many failed attempts! Please try again after 10 minutes.";
                    } 
                    else 
                    {
                        // Update failed attempts count
                        $updateSQL = "UPDATE users SET failed_attempts = ? WHERE id = ?";
                        $updateStmt = $conn->prepare($updateSQL);
                        $updateStmt->bind_param("ii", $failedAttempts, $userId);
                        $_SESSION['error'] = "Incorrect password! You have " . (3 - $failedAttempts) . " attempts left.";
                    }

                    $updateStmt->execute();
                }
            }
        }
        else
        {
            $_SESSION['error'] = "Username not found!";
        }
    }
    // Redirect to login page if something is not right.
    header("location: login.php"); exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Login</title>
    <?php include("../includes/head-contents.php"); ?>
</head>
<body>

    <?php include("../includes/navbar.php"); ?>

    <div class="container my-5">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="box">
                    <?php include("../includes/messages.php"); ?>
                    <form action="login.php" method="POST">
                        <h3 class="fw-bold text-center">LOGIN</h3>
                        <hr>                        
                        <div class="my-3">
                            <label>Username</label>
                            <input type="text" class="form-control" name="email" required>
                        </div>
                        <div class="my-3">
                            <label>Password</label>
                            <input type="password" class="form-control" name="password" required>
                        </div>
                        <div class="my-3">
                            <input type="submit" class="btn btn-danger btn-lg w-100" name="login" value="Login">
                        </div>
                        <div class="my-3 text-center">
                            <span>Don't have an account?</span>
                            <a href="register.php" class="btn btn-link text-danger">Register here</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <?php include("../includes/footer.php"); ?>
</body>
</html>