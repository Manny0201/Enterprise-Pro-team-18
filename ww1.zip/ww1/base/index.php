<!DOCTYPE html>
<html lang="en">
<head>
    <title>Home</title>
    <?php include("../includes/head-contents.php"); ?>
</head>
<body>

    <?php include("../includes/navbar.php"); ?>
    <div class="container-fluid">
        <img src="../images/1.avif" style="width: 100%; height: 400px;">
    </div>

    <div class="container my-5">
        <div class="row">
            <div class="col-md-4">
                <div class="card d-flex flex-column shadow" style="min-height: 580px;">
                    <img class="card-img-top" src="../images/2.jpg" style="height: 350px;" alt="Card image">
                    <div class="card-body d-flex flex-column">
                        <h4 class="card-title">Bradford Soldiers Biography</h4>
                        <p class="card-text">Explore the stories of Bradford soldiers who fought bravely in the trenches of France and beyond.</p>
                        <a href="#" class="btn btn-danger mt-auto">Click Here</a>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card d-flex flex-column shadow" style="min-height: 580px;">
                    <img class="card-img-top" src="../images/3.jpg" style="height: 350px;" alt="Card image">
                    <div class="card-body d-flex flex-column">
                        <h4 class="card-title">Bradford Great War Role of Honour</h4>
                        <p class="card-text">Learn about the men and women who supported the war effort from home, working in factories and hospitals.</p>
                        <a href="#" class="btn btn-danger mt-auto">Click Here</a>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card d-flex flex-column shadow" style="min-height: 580px;">
                    <img class="card-img-top" src="../images/4.jpg" style="height: 350px;" alt="Card image">
                    <div class="card-body d-flex flex-column">
                        <h4 class="card-title">Bradford Memorials</h4>
                        <p class="card-text">Discover the memorials dedicated to the fallen heroes of Bradford.</p>
                        <a href="#" class="btn btn-danger mt-auto">Click Here</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php include("../includes/footer.php"); ?>
    
</body>
</html>