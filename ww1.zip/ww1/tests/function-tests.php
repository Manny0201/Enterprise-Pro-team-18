<?php
// Test suite for uploadImage and timestampToCustomHumanReadable functions

// Include the functions file that contains the functions to be tested
include_once("../includes/helpers.php"); // Adjust path as needed

// Start the session (needed for $_SESSION error messages)
session_start();

class FunctionTests {
    private $testsPassed = 0;
    private $testsFailed = 0;
    private $testResults = [];
    
    /**
     * Run all tests
     */
    public function runAllTests() {
        echo "<h1>PHP Functions Test Suite</h1>";
        
        // Test uploadImage function
        $this->testUploadImage();
        
        // Test timestampToCustomHumanReadable function
        $this->testTimestampToCustomHumanReadable();
        
        // Display summary
        $this->displaySummary();
    }
    
    /**
     * Assert that two values are equal
     */
    private function assertEquals($expected, $actual, $message = "") {
        if ($expected === $actual) {
            $this->testsPassed++;
            $this->testResults[] = [
                'status' => 'PASS',
                'message' => $message,
                'expected' => $expected,
                'actual' => $actual
            ];
            return true;
        } else {
            $this->testsFailed++;
            $this->testResults[] = [
                'status' => 'FAIL',
                'message' => $message,
                'expected' => $expected,
                'actual' => $actual
            ];
            return false;
        }
    }
    
    /**
     * Assert that a value is not null
     */
    private function assertNotNull($actual, $message = "") {
        if ($actual !== null) {
            $this->testsPassed++;
            $this->testResults[] = [
                'status' => 'PASS',
                'message' => $message
            ];
            return true;
        } else {
            $this->testsFailed++;
            $this->testResults[] = [
                'status' => 'FAIL',
                'message' => $message
            ];
            return false;
        }
    }
    
    /**
     * Assert that a condition is true
     */
    private function assertTrue($condition, $message = "") {
        if ($condition) {
            $this->testsPassed++;
            $this->testResults[] = [
                'status' => 'PASS',
                'message' => $message
            ];
            return true;
        } else {
            $this->testsFailed++;
            $this->testResults[] = [
                'status' => 'FAIL',
                'message' => $message
            ];
            return false;
        }
    }
    
    /**
     * Display test results
     */
    private function displaySummary() {
        echo "<h2>Test Results</h2>";
        echo "<div style='margin-bottom: 10px;'>";
        echo "<strong>Tests Passed:</strong> {$this->testsPassed}, ";
        echo "<strong>Tests Failed:</strong> {$this->testsFailed}";
        echo "</div>";
        
        echo "<table border='1' cellpadding='5' style='border-collapse: collapse; width: 100%;'>";
        echo "<tr style='background-color: #f2f2f2;'>";
        echo "<th>Status</th><th>Test</th><th>Details</th>";
        echo "</tr>";
        
        foreach ($this->testResults as $result) {
            $statusColor = $result['status'] === 'PASS' ? '#d4edda' : '#f8d7da';
            echo "<tr style='background-color: {$statusColor};'>";
            echo "<td>{$result['status']}</td>";
            echo "<td>{$result['message']}</td>";
            echo "<td>";
            
            if (isset($result['expected']) && isset($result['actual'])) {
                echo "Expected: " . var_export($result['expected'], true);
                echo "<br>Actual: " . var_export($result['actual'], true);
            }
            
            echo "</td>";
            echo "</tr>";
        }
        
        echo "</table>";
    }
    
    /**
     * Test uploadImage function
     */
    public function testUploadImage() {
        echo "<h2>Testing uploadImage Function</h2>";
        
        // Prepare test directory
        $uploadDir = 'test_uploads/';
        if (!file_exists($uploadDir)) {
            mkdir($uploadDir, 0777, true);
        }
        
        // Test 1: Valid image upload (JPEG)
        $this->testValidImageUpload($uploadDir, 'image/jpeg', 'jpg', 'Valid JPEG image upload');
        
        // Test 2: Valid image upload (PNG)
        $this->testValidImageUpload($uploadDir, 'image/png', 'png', 'Valid PNG image upload');
        
        // Test 3: Invalid image type
        $this->testInvalidImageType($uploadDir);
        
        // Test 4: File too large
        $this->testFileTooLarge($uploadDir);
        
        // Test 5: File upload error
        $this->testFileUploadError($uploadDir);
        
        // Clean up test directory
        $this->cleanupTestDirectory($uploadDir);
    }
    
    /**
     * Test valid image upload
     */
    private function testValidImageUpload($uploadDir, $mimeType, $extension, $testMessage) {
        // Create a mock $_FILES array
        $file = [
            'name' => "test_image.{$extension}",
            'type' => $mimeType,
            'tmp_name' => "../images/test_image.{$extension}", // Path to an existing test image
            'error' => 0,
            'size' => 40000 // 40KB
        ];
        
        // If test image doesn't exist, create a dummy image
        if (!file_exists($file['tmp_name'])) {
            $this->createDummyImage($file['tmp_name'], $extension);
        }
        
        // Test image upload
        $fileName = uploadImage($file, $uploadDir, 'test');
        
        // Check if file was uploaded successfully
        $this->assertNotNull($fileName, $testMessage);
        
       
    }
    
    /**
     * Test invalid image type
     */
    private function testInvalidImageType($uploadDir) {
        // Reset session error message
        $_SESSION['error'] = '';
        
        // Create a mock $_FILES array with invalid type
        $file = [
            'name' => 'test_document.pdf',
            'type' => 'application/pdf',
            'tmp_name' => '../images/test_document.pdf',
            'error' => 0,
            'size' => 30000
        ];
        
        // Create dummy file if needed
        if (!file_exists($file['tmp_name'])) {
            file_put_contents($file['tmp_name'], 'PDF test content');
        }
        
        // Test upload with invalid type
        $fileName = uploadImage($file, $uploadDir);
        
        // Check results
        $this->assertEquals(null, $fileName, "Invalid image type should return null");
        $this->assertTrue(
            isset($_SESSION['error']) && !empty($_SESSION['error']),
            "Error message should be set for invalid image type"
        );
    }
    
    /**
     * Test file too large
     */
    private function testFileTooLarge($uploadDir) {
        // Reset session error message
        $_SESSION['error'] = '';
        
        // Create a mock $_FILES array with large file
        $file = [
            'name' => 'large_image.jpg',
            'type' => 'image/jpeg',
            'tmp_name' => '../images/large_image.jpg',
            'error' => 0,
            'size' => 600000 // 600KB, exceeds the default 500KB limit
        ];
        
        // Test upload with large file
        $fileName = uploadImage($file, $uploadDir);
        
        // Check results
        $this->assertEquals(null, $fileName, "Too large file should return null");
        $this->assertTrue(
            isset($_SESSION['error']) && !empty($_SESSION['error']),
            "Error message should be set for file size exceeding limit"
        );
    }
    
    /**
     * Test file upload error
     */
    private function testFileUploadError($uploadDir) {
        // Create a mock $_FILES array with upload error
        $file = [
            'name' => 'failed_upload.jpg',
            'type' => 'image/jpeg',
            'tmp_name' => '',
            'error' => 1, // Upload error
            'size' => 30000
        ];
        
        // Test upload with error
        $fileName = uploadImage($file, $uploadDir);
        
        // Check result
        $this->assertEquals(null, $fileName, "File with upload error should return null");
    }
    
    /**
     * Create a dummy image for testing
     */
    private function createDummyImage($path, $extension) {
        // Create directory if it doesn't exist
        $dir = dirname($path);
        if (!file_exists($dir)) {
            mkdir($dir, 0777, true);
        }
        
        // Create a simple image
        $image = imagecreatetruecolor(100, 100);
        $bgColor = imagecolorallocate($image, 255, 255, 255);
        $textColor = imagecolorallocate($image, 0, 0, 0);
        imagefilledrectangle($image, 0, 0, 100, 100, $bgColor);
        imagestring($image, 5, 10, 40, 'Test Image', $textColor);
        
        // Save the image based on extension
        if ($extension == 'jpg' || $extension == 'jpeg') {
            imagejpeg($image, $path);
        } else if ($extension == 'png') {
            imagepng($image, $path);
        }
        
        imagedestroy($image);
    }
    
    /**
     * Clean up test directory
     */
    private function cleanupTestDirectory($dir) {
        if (is_dir($dir)) {
            $files = glob($dir . '*');
            foreach ($files as $file) {
                if (is_file($file)) {
                    unlink($file);
                }
            }
        }
    }
    
    /**
     * Test timestampToCustomHumanReadable function
     */
    public function testTimestampToCustomHumanReadable() {
        echo "<h2>Testing timestampToCustomHumanReadable Function</h2>";
        
        $currentTime = time();
        
        // Test cases
        $this->testTimeAgo($currentTime - 30, "0 minute ago", "Should handle very recent timestamps");
        $this->testTimeAgo($currentTime - 60, "1 minute ago", "Should show 1 minute ago");
        $this->testTimeAgo($currentTime - 120, "2 minutes ago", "Should show 2 minutes ago");
        $this->testTimeAgo($currentTime - (60*60), "1 hour ago", "Should show 1 hour ago");
        $this->testTimeAgo($currentTime - (60*60*3), "3 hours ago", "Should show 3 hours ago");
        $this->testTimeAgo($currentTime - (60*60*24), "1 day ago", "Should show 1 day ago");
        $this->testTimeAgo($currentTime - (60*60*24*5), "5 days ago", "Should show 5 days ago");
        $this->testTimeAgo($currentTime - (60*60*24*7), "1 week ago", "Should show 1 week ago");
        $this->testTimeAgo($currentTime - (60*60*24*14), "2 weeks ago", "Should show 2 weeks ago");
        $this->testTimeAgo($currentTime - (60*60*24*30), "1 month ago", "Should show 1 month ago");
        $this->testTimeAgo($currentTime - (60*60*24*30*6), "6 months ago", "Should show 6 months ago");
        $this->testTimeAgo($currentTime - (60*60*24*365), "1 year ago", "Should show 1 year ago");
        $this->testTimeAgo($currentTime - (60*60*24*365*3), "3 years ago", "Should show 3 years ago");
    }
    
    /**
     * Test a specific time ago case
     */
    private function testTimeAgo($timestamp, $expected, $testMessage) {
        $result = timestampToCustomHumanReadable($timestamp);
        
        // For the case where the result might be "0 minutes ago" or "1 minute ago" depending on exact timing
        if ($expected === "0 minute ago" && ($result === "0 minute ago" || $result === "1 minute ago")) {
            $this->assertTrue(true, $testMessage);
        } else {
            $this->assertEquals($expected, $result, $testMessage);
        }
    }
}

// Run tests
$tester = new FunctionTests();
$tester->runAllTests();
?>