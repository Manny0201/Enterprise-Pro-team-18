<?php
// auth-functions.php - Contains all authentication related functions

/**
 * Process login request
 * @param string $email Username input
 * @param string $password Password input
 * @param object $conn Database connection
 * @return array Result with status and message
 */
function processLogin($email, $password, $conn) {
    $result = ['success' => false, 'message' => ''];
    
    // Data validation
    if (empty($email) || empty($password)) {
        return ['success' => false, 'message' => "Please fill all fields!"];
    }
    
    // Sql query to check username exists in users table
    $sql = "SELECT * FROM users WHERE username = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $queryResult = $stmt->get_result();
    $user = $queryResult->fetch_assoc();

    if($user) {
        $userId = $user['id'];
        $failedAttempts = $user['failed_attempts'];
        $lockoutTime = $user['lockout_time'];
        
        // Check if user is currently locked out
        if ($lockoutTime && strtotime($lockoutTime) > time()) {
            return ['success' => false, 'message' => "Too many failed login attempts. Please try again after 10 minutes."];
        } else {
            // Verify user password
            if (password_verify($password, $user['password'])) {
                // Reset failed attempts on successful login
                $updateSQL = "UPDATE users SET failed_attempts = 0, lockout_time = NULL WHERE id = ?";
                $updateStmt = $conn->prepare($updateSQL);
                $updateStmt->bind_param("i", $userId);
                $updateStmt->execute();

                // Return user data
                return [
                    'success' => true,
                    'userId' => $user['id'],
                    'username' => $user['username'],
                    'userEmail' => $user['email'],
                    'userRole' => $user['role']
                ];
            } else {
                $failedAttempts++;

                // If failed attempts reach 3, lock the user out for 10 minutes
                if ($failedAttempts >= 3) {
                    $lockoutTime = date('Y-m-d H:i:s', strtotime("+10 minutes"));
                    $updateSQL = "UPDATE users SET failed_attempts = ?, lockout_time = ? WHERE id = ?";
                    $updateStmt = $conn->prepare($updateSQL);
                    $updateStmt->bind_param("isi", $failedAttempts, $lockoutTime, $userId);
                    return ['success' => false, 'message' => "Too many failed attempts! Please try again after 10 minutes."];
                } else {
                    // Update failed attempts count
                    $updateSQL = "UPDATE users SET failed_attempts = ? WHERE id = ?";
                    $updateStmt = $conn->prepare($updateSQL);
                    $updateStmt->bind_param("ii", $failedAttempts, $userId);
                    $updateStmt->execute();
                    return ['success' => false, 'message' => "Incorrect password! You have " . (3 - $failedAttempts) . " attempts left."];
                }
            }
        }
    } else {
        return ['success' => false, 'message' => "Username not found!"];
    }
}

/**
 * Process registration request
 * @param string $username Username input
 * @param string $email Email input
 * @param string $password Password input
 * @param string $confirmPassword Confirm password input
 * @param object $conn Database connection
 * @return array Result with status and message
 */
function processRegistration($username, $email, $password, $confirmPassword, $conn) {
    // Data validation
    $pattern = "/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).{8,}$/"; 
    
    if (empty($username) || empty($email) || empty($password) || empty($confirmPassword)) {
        return ['success' => false, 'message' => "Please fill all fields!"];
    } 
    
    if($password != $confirmPassword) {
        // Check if password and confirm password do not match
        return ['success' => false, 'message' => "Passwords do not match!"];
    }
    
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        // Check the email format
        return ['success' => false, 'message' => "Use correct email format!"];
    }
    
    if(!preg_match($pattern, $password)) {
        // check the password pattern
        return ['success' => false, 'message' => "Password must contain at least one number, one uppercase, one lowercase letter, and at least 8 or more characters!"];
    }
    
    // Sql query to check if email exists in users table
    $sql = "SELECT * FROM users WHERE email = ? OR username = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $email, $username);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();

    if($user) {
        return ['success' => false, 'message' => "Email or username already exists!"];
    } else {
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);  // Password Encryption
        // Sql query to insert user record
        $sql = "INSERT INTO users (username, email, password) VALUES (?,?,?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sss", $username, $email, $hashedPassword);
        
        if ($stmt->execute()) {
            return ['success' => true, 'message' => "User created successfully!"];
        } else {
            return ['success' => false, 'message' => "Something went wrong!"];
        }
    }
}

/**
 * Process change password request
 * @param int $userId User ID
 * @param string $oldPassword Old password
 * @param string $newPassword New password
 * @param string $confirmPassword Confirm new password
 * @param object $conn Database connection
 * @return array Result with status and message
 */
function processChangePassword($userId, $oldPassword, $newPassword, $confirmPassword, $conn) {
    // Data validation
    $pattern = "/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).{8,}$/"; 
    
    if (empty($oldPassword) || empty($newPassword) || empty($confirmPassword)) {
        return ['success' => false, 'message' => "Please fill all fields!"];
    } 
    
    if($newPassword != $confirmPassword) {
        // Check if password and confirm password do not match
        return ['success' => false, 'message' => "Passwords do not match!"];
    }
    
    if(!preg_match($pattern, $newPassword)) {
        // check the password pattern
        return ['success' => false, 'message' => "Password must contain at least one number, one uppercase, one lowercase letter, and at least 8 or more characters!"];
    }
    
    //Sql query to check if email exists in users table
    $sql = "SELECT * FROM users WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();

    if (!password_verify($oldPassword, $user['password'])) {
        return ['success' => false, 'message' => "Password does not match with our records!"];
    } else {
        $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);  // Password Encryption
        // Sql query to update user's password
        $sql = "UPDATE users SET password = ? WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("si", $hashedPassword, $userId);
        
        if ($stmt->execute()) {
            return ['success' => true, 'message' => "Password updated successfully!"];
        } else {
            return ['success' => false, 'message' => "Something went wrong!"];
        }
    }
}
?>