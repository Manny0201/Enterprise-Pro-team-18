<?php
// auth-test-runner.php - Script to run the authentication tests

// Display all errors for debugging
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Include the auth functions
require_once(__DIR__ . '/auth-functions.php');

// Include the test suite
require_once(__DIR__ . '/auth-tests.php');

// Add styling
echo '<!DOCTYPE html>
<html>
<head>
    <title>Authentication Tests</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            line-height: 1.6;
        }
        h1 {
            color: #333;
            border-bottom: 2px solid #ddd;
            padding-bottom: 10px;
        }
        h2 {
            color: #444;
            margin-top: 30px;
            border-bottom: 1px solid #eee;
            padding-bottom: 5px;
        }
        table {
            border-collapse: collapse;
            width: 100%;
            margin-top: 20px;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 8px;
        }
        th {
            background-color: #f2f2f2;
            text-align: left;
        }
        .pass {
            background-color: #d4edda;
        }
        .fail {
            background-color: #f8d7da;
        }
        .test-selector {
            margin: 20px 0;
            padding: 15px;
            border: 1px solid #ddd;
            background: #f9f9f9;
            border-radius: 5px;
        }
        .test-selector h3 {
            margin-top: 0;
        }
        .test-selector label {
            display: block;
            margin: 10px 0;
        }
        .btn {
            padding: 8px 15px;
            background: #007bff;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        .btn:hover {
            background: #0069d9;
        }
    </style>
</head>
<body>
   ';



    $tester = new AuthenticationTests();
    
    
    $tester->runAllTests();
    
echo '</body>
</html>';
?>