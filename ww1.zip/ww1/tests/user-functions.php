<?php
// user-functions.php - Core functions for user management operations

/**
 * Process user creation request
 * 
 * @param string $username The username
 * @param string $email The email address
 * @param string $password The password
 * @param string $confirmPassword The confirmation password
 * @param object $conn Database connection object
 * @param array $fileData File upload data (optional)
 * @return array Status and message
 */
function processUserCreate($username, $email, $password, $confirmPassword, $conn, $fileData = null) {
    $imageName = null;

    // Data validation
    if (empty($username) || empty($email) || empty($password) || empty($confirmPassword)) {
        return ['success' => false, 'message' => "Please fill all fields!"];
    } else if($password != $confirmPassword) {
        // Check if password and confirm password do not match
        return ['success' => false, 'message' => "Passwords do not match!"];
    } else if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        // Check the email format
        return ['success' => false, 'message' => "Use correct email format!"];
    } else if(!preg_match("/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).{8,}$/", $password)) {
        // check the password pattern
        return ['success' => false, 'message' => "Password must contain at least one number, one uppercase, one lowercase letter, and at least 8 or more characters!"];
    }

    // Sql query to check if email exists in users table
    $sql = "SELECT * FROM users WHERE email = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();

    if($user) {
        return ['success' => false, 'message' => "Email already exists!"];
    }

    // Handle image upload if provided
    if ($fileData !== null && !empty($fileData['name'])) {
        // In a test environment, we'll just simulate this
        $imageName = "user_" . time() . "_" . $fileData['name'];
    }

    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
    
    // Prepare for database insertion
    $sql = "INSERT INTO users (username, email, password, image) VALUES (?,?,?,?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssss", $username, $email, $hashedPassword, $imageName);
    
    if ($stmt->execute()) {
        return ['success' => true, 'message' => "User created successfully!"];
    } else {
        return ['success' => false, 'message' => "Something went wrong!"];
    }
}

/**
 * Process user update request
 * 
 * @param int $id User ID
 * @param string $username The username
 * @param string $email The email address
 * @param string $oldImage Current image filename
 * @param object $conn Database connection object
 * @param array $fileData File upload data (optional)
 * @return array Status and message
 */
function processUserUpdate($id, $username, $email, $oldImage, $conn, $fileData = null) {
    $imageName = $oldImage;

    // Data validation
    if (empty($id) || empty($username) || empty($email)) {
        return ['success' => false, 'message' => "Please fill all fields!"];
    } else if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        // Check the email format
        return ['success' => false, 'message' => "Use correct email format!"];
    }

    // SQL query to check if email exists in users table but exclude current user
    $sql = "SELECT * FROM users WHERE email = ? AND id != ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("si", $email, $id);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();

    if($user) {
        return ['success' => false, 'message' => "Email already exists!"];
    }

    // Handle image upload if provided
    if ($fileData !== null && !empty($fileData['name'])) {
        // In a test environment, we'll just simulate this
        $imageName = "user_" . time() . "_" . $fileData['name'];
    }

    // Sql query to update user record
    $sql = "UPDATE users SET username = ?, email = ?, image = ? WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssi", $username, $email, $imageName, $id);
    
    if ($stmt->execute()) {
        return ['success' => true, 'message' => "User updated successfully!"];
    } else {
        return ['success' => false, 'message' => "Something went wrong!"];
    }
}

/**
 * Process user deletion request
 * 
 * @param int $id User ID
 * @param object $conn Database connection object
 * @return array Status and message
 */
function processUserDelete($id, $conn) {
    // Validate input
    if (!filter_var($id, FILTER_VALIDATE_INT)) {
        return ['success' => false, 'message' => "Invalid user ID!"];
    }
    
    // Check if the user exists and get image information
    $sql = "SELECT * FROM users WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();
    
    if (!$user) {
        return ['success' => false, 'message' => "User not found!"];
    }
    
    // Delete the user
    $sql = "DELETE FROM users WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);
    
    if ($stmt->execute()) {
        return ['success' => true, 'message' => "User deleted successfully!"];
    } else {
        return ['success' => false, 'message' => "Something went wrong!"];
    }
}

/**
 * Get user by ID
 * 
 * @param int $id User ID
 * @param object $conn Database connection object
 * @return array|null User data or null if not found
 */
function getUserById($id, $conn) {
    // Validate input
    if (!filter_var($id, FILTER_VALIDATE_INT)) {
        return null;
    }
    
    // SQL statement to get user record
    $sql = "SELECT * FROM users WHERE id = ? AND role = 'u'";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows == 0) {
        return null;
    }
    
    return $result->fetch_assoc();
}

/**
 * Get all users
 * 
 * @param object $conn Database connection object
 * @return array List of users
 */
function getAllUsers($conn) {
    // SQL query to get all users
    $sql = "SELECT * FROM users WHERE role = 'u' ORDER BY created_at DESC";
    $stmt = $conn->prepare($sql);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $users = [];
    while ($user = $result->fetch_assoc()) {
        $users[] = $user;
    }
    
    return $users;
}
?>