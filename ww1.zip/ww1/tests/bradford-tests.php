<?php
// bradford-tests.php - Test cases for the Bradford management functions

// Include Bradford functions if not already included
if (!function_exists('processBradfordCreate')) {
    require_once(__DIR__ . '/bradford-functions.php');
}

// Mock database classes (reuse from user tests)
class MockDatabaseConnector {
    private $mockResult;
    private $lastQuery = '';
    private $lastParams = [];
    private $executeResult = true;
  
    public function __construct() {
        $this->mockResult = null;
    }
  
    public function setMockResult($result) {
        $this->mockResult = $result;
    }

    public function setExecuteResult($result) {
        $this->executeResult = $result;
    }
  
    public function prepare($query) {
        $this->lastQuery = $query;
        return new MockStatement($this->mockResult, $this, $this->executeResult);
    }
    
    public function setLastParams($params) {
        $this->lastParams = $params;
    }
    
    public function getLastQuery() {
        return $this->lastQuery;
    }
    
    public function getLastParams() {
        return $this->lastParams;
    }
}

class MockStatement {
    private $mockResult;
    private $mockConn;
    private $params = [];
    private $executeResult = true;
  
    public function __construct($mockResult, $mockConn, $executeResult = true) {
        $this->mockResult = $mockResult;
        $this->mockConn = $mockConn;
        $this->executeResult = $executeResult;
    }
  
    public function bind_param($types, ...$params) {
        $this->params = $params;
        $this->mockConn->setLastParams($params);
        return true;
    }
  
    public function execute() {
        return $this->executeResult;
    }
  
    public function get_result() {
        return new MockResult($this->mockResult);
    }
}

class MockResult {
    private $mockData;
    private $index = 0;
    public $num_rows = 0;
  
    public function __construct($mockData) {
        $this->mockData = $mockData;
        
        if (is_array($mockData)) {
            if (isset($mockData[0]) && is_array($mockData[0])) {
                // Array of rows
                $this->num_rows = count($mockData);
            } elseif (!empty($mockData)) {
                // Single row
                $this->num_rows = 1;
                $this->mockData = [$mockData];
            }
        }
    }
  
    public function fetch_assoc() {
        if ($this->mockData === null || $this->index >= $this->num_rows) {
            return null;
        }
        
        if (isset($this->mockData[$this->index])) {
            return $this->mockData[$this->index++];
        }
        
        return null;
    }
}

class BradfordManagementTests {
    private $testsPassed = 0;
    private $testsFailed = 0;
    private $testResults = [];
    private $mockConn;
    
    /**
     * Set up mock connection and statement objects
     */
    public function setUp($mockData = null) {
        // Create mock database connector
        $this->mockConn = new MockDatabaseConnector();
        $this->mockConn->setMockResult($mockData);
        
        // Define global $conn to reference our mock
        global $conn;
        $conn = $this->mockConn;
        
        return $this->mockConn;
    }
    
    /**
     * Run all tests
     */
    public function runAllTests() {
        echo "<h1>Bradford Management Tests Suite</h1>";
        
        // Test Bradford creation functionality
        $this->testBradfordCreation();
        
        // Test Bradford update functionality
        $this->testBradfordUpdate();
        
        // Test Bradford deletion functionality
        $this->testBradfordDelete();
        
        // Test get Bradford by ID
        $this->testGetBradfordById();
        
        // Test get all Bradfords
        $this->testGetAllBradfords();
        
        // Display summary
        $this->displaySummary();
    }
    
    /**
     * Assert that two values are equal
     */
    private function assertEquals($expected, $actual, $message = "") {
        if ($expected === $actual) {
            $this->testsPassed++;
            $this->testResults[] = [
                'status' => 'PASS',
                'message' => $message,
                'expected' => $expected,
                'actual' => $actual
            ];
            return true;
        } else {
            $this->testsFailed++;
            $this->testResults[] = [
                'status' => 'FAIL',
                'message' => $message,
                'expected' => $expected,
                'actual' => $actual
            ];
            return false;
        }
    }
    
    /**
     * Assert that a condition is true
     */
    private function assertTrue($condition, $message = "") {
        if ($condition) {
            $this->testsPassed++;
            $this->testResults[] = [
                'status' => 'PASS',
                'message' => $message
            ];
            return true;
        } else {
            $this->testsFailed++;
            $this->testResults[] = [
                'status' => 'FAIL',
                'message' => $message
            ];
            return false;
        }
    }
    
    /**
     * Display test results
     */
    public function displaySummary() {
        echo "<h2>Test Results</h2>";
        echo "<div style='margin-bottom: 10px;'>";
        echo "<strong>Tests Passed:</strong> {$this->testsPassed}, ";
        echo "<strong>Tests Failed:</strong> {$this->testsFailed}";
        echo "</div>";
        
        echo "<table border='1' cellpadding='5' style='border-collapse: collapse; width: 100%;'>";
        echo "<tr style='background-color: #f2f2f2;'>";
        echo "<th>Status</th><th>Test</th><th>Details</th>";
        echo "</tr>";
        
        foreach ($this->testResults as $result) {
            $statusColor = $result['status'] === 'PASS' ? '#d4edda' : '#f8d7da';
            echo "<tr style='background-color: {$statusColor};'>";
            echo "<td>{$result['status']}</td>";
            echo "<td>{$result['message']}</td>";
            echo "<td>";
            
            if (isset($result['expected']) && isset($result['actual'])) {
                echo "Expected: ";
                echo "<pre>" . print_r($result['expected'], true) . "</pre>";
                echo "Actual: ";
                echo "<pre>" . print_r($result['actual'], true) . "</pre>";
            }
            
            echo "</td>";
            echo "</tr>";
        }
        
        echo "</table>";
    }
    
    /**
     * Test Bradford creation functionality
     */
    public function testBradfordCreation() {
        echo "<h2>Testing Bradford Creation Functions</h2>";
        
        // Test 1: Empty required fields validation
        $this->testEmptyFieldsBradfordCreate();
        
        // Test 2: Successful Bradford creation
        $this->testSuccessfulBradfordCreate();

        // Test 3: Database error
        $this->testDatabaseErrorBradfordCreate();
    }
    
    /**
     * Test empty required fields in Bradford creation
     */
    private function testEmptyFieldsBradfordCreate() {
        // Set up mock with no data
        $this->setUp(null);
        
        // Create form data with empty required fields
        $formData = [
            'Surname' => '',
            'Forename' => '',
            'Address' => 'Test Address',
            'Electoral_Ward' => 'Test Ward',
            'Town' => 'Test Town',
            'Rank' => 'Test Rank',
            'Regiment' => 'Test Regiment',
            'Unit' => 'Test Unit',
            'Company' => 'Test Company',
            'Age' => '25',
            'Service_No' => '12345',
            'Other_Regiment' => 'Test Other Regiment',
            'Other_Unit' => 'Test Other Unit',
            'Other_Service_No' => '67890',
            'Medals' => 'Test Medals',
            'Enlistment_date' => '2025-01-01',
            'Discharge_date' => '2025-02-01',
            'Death_in_service_date' => '',
            'Misc_Info_Nroh' => 'Test Info',
            'Cemetery_Memorial' => 'Test Cemetery',
            'Cemetery_Memorial_Ref' => 'Test Ref',
            'Cemetery_Memorial_Country' => 'Test Country',
            'Additional_CWGC_info' => 'Test Additional Info'
        ];
        
        // Call the processBradfordCreate function directly
        $result = processBradfordCreate($formData, $this->mockConn);
        
        // Check if the result is correct
        $this->assertEquals(
            ['success' => false, 'message' => 'Please fill all required fields!'],
            $result,
            "Empty required fields validation in Bradford creation"
        );
    }
    
    /**
     * Test successful Bradford creation
     */
    private function testSuccessfulBradfordCreate() {
        // Set up mock with no data
        $mockConn = $this->setUp(null);
        
        // Create complete form data
        $formData = [
            'Surname' => 'Smith',
            'Forename' => 'John',
            'Address' => 'Test Address',
            'Electoral_Ward' => 'Test Ward',
            'Town' => 'Test Town',
            'Rank' => 'Test Rank',
            'Regiment' => 'Test Regiment',
            'Unit' => 'Test Unit',
            'Company' => 'Test Company',
            'Age' => '25',
            'Service_No' => '12345',
            'Other_Regiment' => 'Test Other Regiment',
            'Other_Unit' => 'Test Other Unit',
            'Other_Service_No' => '67890',
            'Medals' => 'Test Medals',
            'Enlistment_date' => '2025-01-01',
            'Discharge_date' => '2025-02-01',
            'Death_in_service_date' => '',
            'Misc_Info_Nroh' => 'Test Info',
            'Cemetery_Memorial' => 'Test Cemetery',
            'Cemetery_Memorial_Ref' => 'Test Ref',
            'Cemetery_Memorial_Country' => 'Test Country',
            'Additional_CWGC_info' => 'Test Additional Info'
        ];
        
        // Call the processBradfordCreate function directly
        $result = processBradfordCreate($formData, $mockConn);
        
        // Check if the result is correct
        $this->assertEquals(
            ['success' => true, 'message' => 'Bradford record created successfully!'],
            $result,
            "Successful Bradford creation"
        );
    }
    
    /**
     * Test database error during Bradford creation
     */
    private function testDatabaseErrorBradfordCreate() {
        // Set up mock with execute error
        $mockConn = $this->setUp(null);
        $mockConn->setExecuteResult(false);
        
        // Create complete form data
        $formData = [
            'Surname' => 'Smith',
            'Forename' => 'John',
            'Address' => 'Test Address',
            'Electoral_Ward' => 'Test Ward',
            'Town' => 'Test Town',
            'Rank' => 'Test Rank',
            'Regiment' => 'Test Regiment',
            'Unit' => 'Test Unit',
            'Company' => 'Test Company',
            'Age' => '25',
            'Service_No' => '12345',
            'Other_Regiment' => 'Test Other Regiment',
            'Other_Unit' => 'Test Other Unit',
            'Other_Service_No' => '67890',
            'Medals' => 'Test Medals',
            'Enlistment_date' => '2025-01-01',
            'Discharge_date' => '2025-02-01',
            'Death_in_service_date' => '',
            'Misc_Info_Nroh' => 'Test Info',
            'Cemetery_Memorial' => 'Test Cemetery',
            'Cemetery_Memorial_Ref' => 'Test Ref',
            'Cemetery_Memorial_Country' => 'Test Country',
            'Additional_CWGC_info' => 'Test Additional Info'
        ];
        
        // Call the processBradfordCreate function directly
        $result = processBradfordCreate($formData, $mockConn);
        
        // Check if the result is correct
        $this->assertEquals(
            ['success' => false, 'message' => 'Something went wrong!'],
            $result,
            "Database error during Bradford creation"
        );
    }
    
    /**
     * Test Bradford update functionality
     */
    public function testBradfordUpdate() {
        echo "<h2>Testing Bradford Update Functions</h2>";
        
        // Test 1: Invalid ID validation
        $this->testInvalidIdBradfordUpdate();
        
        // Test 2: Empty required fields validation
        $this->testEmptyFieldsBradfordUpdate();
        
        // Test 3: Record not found
        $this->testRecordNotFoundBradfordUpdate();
        
        // Test 4: Successful update
        $this->testSuccessfulBradfordUpdate();
        
        // Test 5: Database error
        $this->testDatabaseErrorBradfordUpdate();
    }
    
    /**
     * Test invalid ID validation in Bradford update
     */
    private function testInvalidIdBradfordUpdate() {
        // Set up mock with no data
        $this->setUp(null);
        
        // Create form data
        $formData = [
            'Surname' => 'Smith',
            'Forename' => 'John',
            'Address' => 'Test Address',
            'Electoral_Ward' => 'Test Ward',
            'Town' => 'Test Town',
            'Rank' => 'Test Rank',
            'Regiment' => 'Test Regiment',
            'Unit' => 'Test Unit',
            'Company' => 'Test Company',
            'Age' => '25',
            'Service_No' => '12345',
            'Other_Regiment' => 'Test Other Regiment',
            'Other_Unit' => 'Test Other Unit',
            'Other_Service_No' => '67890',
            'Medals' => 'Test Medals',
            'Enlistment_date' => '2025-01-01',
            'Discharge_date' => '2025-02-01',
            'Death_in_service_date' => '',
            'Misc_Info_Nroh' => 'Test Info',
            'Cemetery_Memorial' => 'Test Cemetery',
            'Cemetery_Memorial_Ref' => 'Test Ref',
            'Cemetery_Memorial_Country' => 'Test Country',
            'Additional_CWGC_info' => 'Test Additional Info'
        ];
        
        // Call the processBradfordUpdate function with invalid ID
        $result = processBradfordUpdate('abc', $formData, $this->mockConn);
        
        // Check if the result is correct
        $this->assertEquals(
            ['success' => false, 'message' => 'Invalid Bradford ID!'],
            $result,
            "Invalid ID validation in Bradford update"
        );
    }
    
    /**
     * Test empty required fields in Bradford update
     */
    private function testEmptyFieldsBradfordUpdate() {
        // Set up mock with no data
        $this->setUp(null);
        
        // Create form data with empty required fields
        $formData = [
            'Surname' => '',
            'Forename' => '',
            'Address' => 'Test Address',
            'Electoral_Ward' => 'Test Ward',
            'Town' => 'Test Town',
            'Rank' => 'Test Rank',
            'Regiment' => 'Test Regiment',
            'Unit' => 'Test Unit',
            'Company' => 'Test Company',
            'Age' => '25',
            'Service_No' => '12345',
            'Other_Regiment' => 'Test Other Regiment',
            'Other_Unit' => 'Test Other Unit',
            'Other_Service_No' => '67890',
            'Medals' => 'Test Medals',
            'Enlistment_date' => '2025-01-01',
            'Discharge_date' => '2025-02-01',
            'Death_in_service_date' => '',
            'Misc_Info_Nroh' => 'Test Info',
            'Cemetery_Memorial' => 'Test Cemetery',
            'Cemetery_Memorial_Ref' => 'Test Ref',
            'Cemetery_Memorial_Country' => 'Test Country',
            'Additional_CWGC_info' => 'Test Additional Info'
        ];
        
        // Call the processBradfordUpdate function with valid ID but empty required fields
        $result = processBradfordUpdate(1, $formData, $this->mockConn);
        
        // Check if the result is correct
        $this->assertEquals(
            ['success' => false, 'message' => 'Please fill all required fields!'],
            $result,
            "Empty required fields validation in Bradford update"
        );
    }
    
    /**
     * Test record not found in Bradford update
     */
    private function testRecordNotFoundBradfordUpdate() {
        // Set up mock with no data
        $this->setUp(null);
        
        // Create complete form data
        $formData = [
            'Surname' => 'Smith',
            'Forename' => 'John',
            'Address' => 'Test Address',
            'Electoral_Ward' => 'Test Ward',
            'Town' => 'Test Town',
            'Rank' => 'Test Rank',
            'Regiment' => 'Test Regiment',
            'Unit' => 'Test Unit',
            'Company' => 'Test Company',
            'Age' => '25',
            'Service_No' => '12345',
            'Other_Regiment' => 'Test Other Regiment',
            'Other_Unit' => 'Test Other Unit',
            'Other_Service_No' => '67890',
            'Medals' => 'Test Medals',
            'Enlistment_date' => '2025-01-01',
            'Discharge_date' => '2025-02-01',
            'Death_in_service_date' => '',
            'Misc_Info_Nroh' => 'Test Info',
            'Cemetery_Memorial' => 'Test Cemetery',
            'Cemetery_Memorial_Ref' => 'Test Ref',
            'Cemetery_Memorial_Country' => 'Test Country',
            'Additional_CWGC_info' => 'Test Additional Info'
        ];
        
        // Call the processBradfordUpdate function with non-existent ID
        $result = processBradfordUpdate(999, $formData, $this->mockConn);
        
        // Check if the result is correct
        $this->assertEquals(
            ['success' => false, 'message' => 'Bradford record not found!'],
            $result,
            "Record not found validation in Bradford update"
        );
    }
    
    /**
     * Test successful Bradford update
     */
    private function testSuccessfulBradfordUpdate() {
        // Mock data for an existing Bradford record
        $mockData = [
            'id' => 1,
            'Surname' => 'Old Surname',
            'Forename' => 'Old Forename'
        ];
        
        // Set up mock with existing record data
        $mockConn = $this->setUp($mockData);
        
        // Create complete form data
        $formData = [
            'Surname' => 'Smith',
            'Forename' => 'John',
            'Address' => 'Test Address',
            'Electoral_Ward' => 'Test Ward',
            'Town' => 'Test Town',
            'Rank' => 'Test Rank',
            'Regiment' => 'Test Regiment',
            'Unit' => 'Test Unit',
            'Company' => 'Test Company',
            'Age' => '25',
            'Service_No' => '12345',
            'Other_Regiment' => 'Test Other Regiment',
            'Other_Unit' => 'Test Other Unit',
            'Other_Service_No' => '67890',
            'Medals' => 'Test Medals',
            'Enlistment_date' => '2025-01-01',
            'Discharge_date' => '2025-02-01',
            'Death_in_service_date' => '',
            'Misc_Info_Nroh' => 'Test Info',
            'Cemetery_Memorial' => 'Test Cemetery',
            'Cemetery_Memorial_Ref' => 'Test Ref',
            'Cemetery_Memorial_Country' => 'Test Country',
            'Additional_CWGC_info' => 'Test Additional Info'
        ];
        
        // Call the processBradfordUpdate function with existing ID
        $result = processBradfordUpdate(1, $formData, $mockConn);
        
        // Check if the result is correct
        $this->assertEquals(
            ['success' => true, 'message' => 'Bradford record updated successfully!'],
            $result,
            "Successful Bradford update"
        );
    }
    
    /**
     * Test database error during Bradford update
     */
    private function testDatabaseErrorBradfordUpdate() {
        // Mock data for an existing Bradford record
        $mockData = [
            'id' => 1,
            'Surname' => 'Old Surname',
            'Forename' => 'Old Forename'
        ];
        
        // Set up mock with existing record data and execute error
        $mockConn = $this->setUp($mockData);
        $mockConn->setExecuteResult(false);
        
        // Create complete form data
        $formData = [
            'Surname' => 'Smith',
            'Forename' => 'John',
            'Address' => 'Test Address',
            'Electoral_Ward' => 'Test Ward',
            'Town' => 'Test Town',
            'Rank' => 'Test Rank',
            'Regiment' => 'Test Regiment',
            'Unit' => 'Test Unit',
            'Company' => 'Test Company',
            'Age' => '25',
            'Service_No' => '12345',
            'Other_Regiment' => 'Test Other Regiment',
            'Other_Unit' => 'Test Other Unit',
            'Other_Service_No' => '67890',
            'Medals' => 'Test Medals',
            'Enlistment_date' => '2025-01-01',
            'Discharge_date' => '2025-02-01',
            'Death_in_service_date' => '',
            'Misc_Info_Nroh' => 'Test Info',
            'Cemetery_Memorial' => 'Test Cemetery',
            'Cemetery_Memorial_Ref' => 'Test Ref',
            'Cemetery_Memorial_Country' => 'Test Country',
            'Additional_CWGC_info' => 'Test Additional Info'
        ];
        
        // Call the processBradfordUpdate function with existing ID but execute error
        $result = processBradfordUpdate(1, $formData, $mockConn);
        
        // Check if the result is correct
        $this->assertEquals(
            ['success' => false, 'message' => 'Something went wrong!'],
            $result,
            "Database error during Bradford update"
        );
    }
    
    /**
     * Test Bradford deletion functionality
     */
    public function testBradfordDelete() {
        echo "<h2>Testing Bradford Deletion Functions</h2>";
        
        // Test 1: Invalid ID validation
        $this->testInvalidIdBradfordDelete();
        
        // Test 2: Record not found
        $this->testRecordNotFoundBradfordDelete();
        
        // Test 3: Successful deletion
        $this->testSuccessfulBradfordDelete();
        
        // Test 4: Database error
        $this->testDatabaseErrorBradfordDelete();
    }
    
    /**
     * Test invalid ID validation in Bradford deletion
     */
    private function testInvalidIdBradfordDelete() {
        // Set up mock with no data
        $this->setUp(null);
        
        // Call the processBradfordDelete function with invalid ID
        $result = processBradfordDelete('abc', $this->mockConn);
        
        // Check if the result is correct
        $this->assertEquals(
            ['success' => false, 'message' => 'Invalid Bradford ID!'],
            $result,
            "Invalid ID validation in Bradford deletion"
        );
    }
    
    /**
     * Test record not found in Bradford deletion
     */
    private function testRecordNotFoundBradfordDelete() {
        // Set up mock with no data
        $this->setUp(null);
        
        // Call the processBradfordDelete function with non-existent ID
        $result = processBradfordDelete(999, $this->mockConn);
        
        // Check if the result is correct
        $this->assertEquals(
            ['success' => false, 'message' => 'Bradford record not found!'],
            $result,
            "Record not found validation in Bradford deletion"
        );
    }
    
    /**
     * Test successful Bradford deletion
     */
    private function testSuccessfulBradfordDelete() {
        // Mock data for an existing Bradford record
        $mockData = [
            'id' => 1,
            'Surname' => 'Smith',
            'Forename' => 'John'
        ];
        
        // Set up mock with existing record data
        $mockConn = $this->setUp($mockData);
        
        // Call the processBradfordDelete function with existing ID
        $result = processBradfordDelete(1, $mockConn);
        
        // Check if the result is correct
        $this->assertEquals(
            ['success' => true, 'message' => 'Bradford record deleted successfully!'],
            $result,
            "Successful Bradford deletion"
        );
    }
    
    /**
     * Test database error during Bradford deletion
     */
    private function testDatabaseErrorBradfordDelete() {
        // Mock data for an existing Bradford record
        $mockData = [
            'id' => 1,
            'Surname' => 'Smith',
            'Forename' => 'John'
        ];
        
        // Set up mock with existing record data and execute error
        $mockConn = $this->setUp($mockData);
        $mockConn->setExecuteResult(false);
        
        // Call the processBradfordDelete function with existing ID but execute error
        $result = processBradfordDelete(1, $mockConn);
        
        // Check if the result is correct
        $this->assertEquals(
            ['success' => false, 'message' => 'Something went wrong!'],
            $result,
            "Database error during Bradford deletion"
        );
    }
    
    /**
     * Test get Bradford by ID functionality
     */
    public function testGetBradfordById() {
        echo "<h2>Testing Get Bradford By ID Functions</h2>";
        
        // Test 1: Invalid ID validation
        $this->testInvalidIdGetBradfordById();
        
        // Test 2: Record not found
        $this->testRecordNotFoundGetBradfordById();
        
        // Test 3: Successful get Bradford by ID
        $this->testSuccessfulGetBradfordById();
    }
    
    /**
     * Test invalid ID validation in get Bradford by ID
     */
    private function testInvalidIdGetBradfordById() {
        // Set up mock with no data
        $this->setUp(null);
        
        // Call the getBradfordById function with invalid ID
        $result = getBradfordById('abc', $this->mockConn);
        
        // Check if the result is correct
        $this->assertEquals(
            null,
            $result,
            "Invalid ID validation in get Bradford by ID"
        );
    }
    
    /**
     * Test record not found in get Bradford by ID
     */
    private function testRecordNotFoundGetBradfordById() {
        // Set up mock with no data
        $this->setUp(null);
        
        // Call the getBradfordById function with non-existent ID
        $result = getBradfordById(999, $this->mockConn);
        
        // Check if the result is correct
        $this->assertEquals(
            null,
            $result,
            "Record not found validation in get Bradford by ID"
        );
    }
    
    /**
     * Test successful get Bradford by ID
     */
    private function testSuccessfulGetBradfordById() {
        // Mock data for an existing Bradford record
        $mockData = [
            'id' => 1,
            'Surname' => 'Smith',
            'Forename' => 'John',
            'Address' => 'Test Address',
            'Electoral Ward' => 'Test Ward',
            'Town' => 'Test Town'
        ];
        
        // Set up mock with existing record data
        $mockConn = $this->setUp($mockData);
        
        // Call the getBradfordById function with existing ID
        $result = getBradfordById(1, $mockConn);
        
        // Check if the result is correct
        $this->assertEquals(
            $mockData,
            $result,
            "Successful get Bradford by ID"
        );
    }
    
    /**
     * Test get all Bradfords functionality
     */
    public function testGetAllBradfords() {
        echo "<h2>Testing Get All Bradfords Functions</h2>";
        
        // Test 1: No records found
        $this->testNoRecordsGetAllBradfords();
        
        // Test 2: Successful get all Bradfords
        $this->testSuccessfulGetAllBradfords();
        
        // Test 3: Get all Bradfords with limit
        $this->testLimitedGetAllBradfords();
    }
    
    /**
     * Test no records found in get all Bradfords
     */
    private function testNoRecordsGetAllBradfords() {
        // Set up mock with no data
        $this->setUp(null);
        
        // Call the getAllBradfords function
        $result = getAllBradfords($this->mockConn);
        
        // Check if the result is correct
        $this->assertEquals(
            [],
            $result,
            "No records found in get all Bradfords"
        );
    }
    
    /**
     * Test successful get all Bradfords
     */
    private function testSuccessfulGetAllBradfords() {
        // Mock data for multiple Bradford records
        $mockData = [
            [
                'id' => 1,
                'Surname' => 'Smith',
                'Forename' => 'John',
                'Address' => 'Test Address 1'
            ],
            [
                'id' => 2,
                'Surname' => 'Johnson',
                'Forename' => 'Jane',
                'Address' => 'Test Address 2'
            ],
            [
                'id' => 3,
                'Surname' => 'Williams',
                'Forename' => 'Robert',
                'Address' => 'Test Address 3'
            ]
        ];
        
        // Set up mock with multiple records data
        $mockConn = $this->setUp($mockData);
        
        // Call the getAllBradfords function
        $result = getAllBradfords($mockConn);
        
        // Check if the result is correct
        $this->assertEquals(
            $mockData,
            $result,
            "Successful get all Bradfords"
        );
    }
    
    /**
     * Test get all Bradfords with limit
     */
    private function testLimitedGetAllBradfords() {
        // Mock data for multiple Bradford records
        $mockData = [
            [
                'id' => 1,
                'Surname' => 'Smith',
                'Forename' => 'John',
                'Address' => 'Test Address 1'
            ],
            [
                'id' => 2,
                'Surname' => 'Johnson',
                'Forename' => 'Jane',
                'Address' => 'Test Address 2'
            ]
        ];
        
        // Set up mock with multiple records data
        $mockConn = $this->setUp($mockData);
        
        // Call the getAllBradfords function with limit
        $result = getAllBradfords($mockConn, 2);
        
        // Check if the result is correct
        $this->assertEquals(
            $mockData,
            $result,
            "Get all Bradfords with limit"
        );
    }
}