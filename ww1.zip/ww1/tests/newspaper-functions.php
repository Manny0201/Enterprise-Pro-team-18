<?php
/**
 * Newspaper Management Functions
 * 
 * This file contains functions for managing newspaper references
 */

/**
 * Process newspaper creation
 * 
 * @param string $surname The surname
 * @param string $forename The forename
 * @param string $rank The rank
 * @param string $address The address
 * @param string $regiment The regiment
 * @param string $unit The unit
 * @param string $articleComment The article comment
 * @param string $newspaperName The newspaper name
 * @param string $newspaperDate The newspaper date
 * @param string $pageCol The page/column
 * @param string $photoIncl Photo included (Yes/No)
 * @param mysqli $conn Database connection
 * @return array Result with success status and message
 */
function processNewspaperCreate($surname, $forename, $rank, $address, $regiment, $unit, 
                             $articleComment, $newspaperName, $newspaperDate, $pageCol, $photoIncl, $conn) {
    // Validate required fields
    if (empty($surname) || empty($forename)) {
        return ['success' => false, 'message' => "Surname and Forename are required!"];
    }

    // SQL query to insert a new newspaper record
    $sql = "INSERT INTO newspaper_references_2025 
        (Surname, Forename, Rank, Address, Regiment, Unit, `Article Comment`, `Newspaper Name`, `Newspaper Date`, `Page/Col`, `Photo incl`) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssssssssss", 
        $surname, $forename, $rank, $address, $regiment, $unit, $articleComment, $newspaperName, $newspaperDate, $pageCol, $photoIncl
    );

    if ($stmt->execute()) {
        return ['success' => true, 'message' => "Newspaper Ref created successfully!"];
    } else {
        return ['success' => false, 'message' => "Something went wrong!"];
    }
}

/**
 * Process newspaper update
 * 
 * @param int $id The newspaper ID
 * @param string $surname The surname
 * @param string $forename The forename
 * @param string $rank The rank
 * @param string $address The address
 * @param string $regiment The regiment
 * @param string $unit The unit
 * @param string $articleComment The article comment
 * @param string $newspaperName The newspaper name
 * @param string $newspaperDate The newspaper date
 * @param string $pageCol The page/column
 * @param string $photoIncl Photo included (Yes/No)
 * @param mysqli $conn Database connection
 * @return array Result with success status and message
 */
function processNewspaperUpdate($id, $surname, $forename, $rank, $address, $regiment, $unit, 
                             $articleComment, $newspaperName, $newspaperDate, $pageCol, $photoIncl, $conn) {
    // Validate required fields
    if (empty($id) || !filter_var($id, FILTER_VALIDATE_INT)) {
        return ['success' => false, 'message' => "Invalid newspaper ID!"];
    }
    
    if (empty($surname) || empty($forename)) {
        return ['success' => false, 'message' => "Surname and Forename are required!"];
    }

    // SQL query to update newspaper record
    $sql = "UPDATE newspaper_references_2025 
            SET Surname = ?, Forename = ?, Rank = ?, Address = ?, Regiment = ?, Unit = ?, 
                `Article Comment` = ?, `Newspaper Name` = ?, `Newspaper Date` = ?, `Page/Col` = ?, `Photo incl` = ? 
            WHERE id = ?";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssssssssssi", 
        $surname, $forename, $rank, $address, $regiment, $unit, $articleComment, $newspaperName, $newspaperDate, $pageCol, $photoIncl, $id
    );

    if ($stmt->execute()) {
        return ['success' => true, 'message' => "Newspaper Ref updated successfully!"];
    } else {
        return ['success' => false, 'message' => "Something went wrong!"];
    }
}

/**
 * Process newspaper deletion
 * 
 * @param int $id The newspaper ID
 * @param mysqli $conn Database connection
 * @return array Result with success status and message
 */
function processNewspaperDelete($id, $conn) {
    // Validate ID
    if (empty($id) || !filter_var($id, FILTER_VALIDATE_INT)) {
        return ['success' => false, 'message' => "Invalid newspaper ID!"];
    }

    // Check if newspaper exists
    $newspaper = getNewspaperById($id, $conn);
    if (!$newspaper) {
        return ['success' => false, 'message' => "Newspaper not found!"];
    }

    // SQL statement to delete
    $sql = "DELETE FROM newspaper_references_2025 WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);

    if ($stmt->execute()) {
        return ['success' => true, 'message' => "Newspaper Ref deleted successfully!"];
    } else {
        return ['success' => false, 'message' => "Something went wrong!"];
    }
}

/**
 * Get newspaper by ID
 * 
 * @param int $id The newspaper ID
 * @param mysqli $conn Database connection
 * @return array|null The newspaper data or null if not found
 */
function getNewspaperById($id, $conn) {
    // Validate ID
    if (empty($id) || !filter_var($id, FILTER_VALIDATE_INT)) {
        return null;
    }

    // SQL statement to get newspaper record
    $sql = "SELECT * FROM newspaper_references_2025 WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows == 0) {
        return null;
    }
    
    return $result->fetch_assoc();
}

/**
 * Get all newspapers
 * 
 * @param mysqli $conn Database connection
 * @param int $limit The maximum number of records to return (optional)
 * @return array The list of newspapers
 */
function getAllNewspapers($conn, $limit = 20) {
    // SQL query to get all newspapers
    $sql = "SELECT * FROM newspaper_references_2025 ORDER BY id DESC";
    
    if ($limit > 0) {
        $sql .= " LIMIT ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $limit);
    } else {
        $stmt = $conn->prepare($sql);
    }
    
    $stmt->execute();
    $result = $stmt->get_result();
    
    $newspapers = [];
    while ($newspaper = $result->fetch_assoc()) {
        $newspapers[] = $newspaper;
    }
    
    return $newspapers;
}