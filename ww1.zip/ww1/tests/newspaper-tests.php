<?php
// newspaper-tests.php - Test cases for the newspaper management functions

// Include newspaper functions if not already included
if (!function_exists('processNewspaperCreate')) {
    require_once(__DIR__ . '/newspaper-functions.php');
}

// Using the same mock classes from user-tests.php
class MockDatabaseConnector {
    private $mockResult;
    private $lastQuery = '';
    private $lastParams = [];
    private $executeResult = true;
  
    public function __construct() {
        $this->mockResult = null;
    }
  
    public function setMockResult($result) {
        $this->mockResult = $result;
    }

    public function setExecuteResult($result) {
        $this->executeResult = $result;
    }
  
    public function prepare($query) {
        $this->lastQuery = $query;
        return new MockStatement($this->mockResult, $this, $this->executeResult);
    }
    
    public function setLastParams($params) {
        $this->lastParams = $params;
    }
    
    public function getLastQuery() {
        return $this->lastQuery;
    }
    
    public function getLastParams() {
        return $this->lastParams;
    }
}

class MockStatement {
    private $mockResult;
    private $mockConn;
    private $params = [];
    private $executeResult = true;
  
    public function __construct($mockResult, $mockConn, $executeResult = true) {
        $this->mockResult = $mockResult;
        $this->mockConn = $mockConn;
        $this->executeResult = $executeResult;
    }
  
    public function bind_param($types, ...$params) {
        $this->params = $params;
        $this->mockConn->setLastParams($params);
        return true;
    }
  
    public function execute() {
        return $this->executeResult;
    }
  
    public function get_result() {
        return new MockResult($this->mockResult);
    }
}

class MockResult {
    private $mockData;
    private $index = 0;
    public $num_rows = 0;
  
    public function __construct($mockData) {
        $this->mockData = $mockData;
        
        if (is_array($mockData)) {
            if (isset($mockData[0]) && is_array($mockData[0])) {
                // Array of rows
                $this->num_rows = count($mockData);
            } elseif (!empty($mockData)) {
                // Single row
                $this->num_rows = 1;
                $this->mockData = [$mockData];
            }
        }
    }
  
    public function fetch_assoc() {
        if ($this->mockData === null || $this->index >= $this->num_rows) {
            return null;
        }
        
        if (isset($this->mockData[$this->index])) {
            return $this->mockData[$this->index++];
        }
        
        return null;
    }
}

class NewspaperManagementTests {
    private $testsPassed = 0;
    private $testsFailed = 0;
    private $testResults = [];
    private $mockConn;
    
    /**
     * Set up mock connection and statement objects
     */
    public function setUp($mockData = null) {
        // Create mock database connector
        $this->mockConn = new MockDatabaseConnector();
        $this->mockConn->setMockResult($mockData);
        
        // Define global $conn to reference our mock
        global $conn;
        $conn = $this->mockConn;
    }
    
    /**
     * Run all tests
     */
    public function runAllTests() {
        echo "<h1>Newspaper Management Tests Suite</h1>";
        
        // Test newspaper creation functionality
        $this->testNewspaperCreation();
        
        // Test newspaper update functionality
        $this->testNewspaperUpdate();
        
        // Test newspaper deletion functionality
        $this->testNewspaperDelete();
        
        // Test get newspaper by ID
        $this->testGetNewspaperById();
        
        // Test get all newspapers
        $this->testGetAllNewspapers();
        
        // Display summary
        $this->displaySummary();
    }
    
    /**
     * Assert that two values are equal
     */
    private function assertEquals($expected, $actual, $message = "") {
        if ($expected === $actual) {
            $this->testsPassed++;
            $this->testResults[] = [
                'status' => 'PASS',
                'message' => $message,
                'expected' => $expected,
                'actual' => $actual
            ];
            return true;
        } else {
            $this->testsFailed++;
            $this->testResults[] = [
                'status' => 'FAIL',
                'message' => $message,
                'expected' => $expected,
                'actual' => $actual
            ];
            return false;
        }
    }
    
    /**
     * Assert that a condition is true
     */
    private function assertTrue($condition, $message = "") {
        if ($condition) {
            $this->testsPassed++;
            $this->testResults[] = [
                'status' => 'PASS',
                'message' => $message
            ];
            return true;
        } else {
            $this->testsFailed++;
            $this->testResults[] = [
                'status' => 'FAIL',
                'message' => $message
            ];
            return false;
        }
    }
    
    /**
     * Display test results
     */
    public function displaySummary() {
        echo "<h2>Test Results</h2>";
        echo "<div style='margin-bottom: 10px;'>";
        echo "<strong>Tests Passed:</strong> {$this->testsPassed}, ";
        echo "<strong>Tests Failed:</strong> {$this->testsFailed}";
        echo "</div>";
        
        echo "<table border='1' cellpadding='5' style='border-collapse: collapse; width: 100%;'>";
        echo "<tr style='background-color: #f2f2f2;'>";
        echo "<th>Status</th><th>Test</th><th>Details</th>";
        echo "</tr>";
        
        foreach ($this->testResults as $result) {
            $statusColor = $result['status'] === 'PASS' ? '#d4edda' : '#f8d7da';
            echo "<tr style='background-color: {$statusColor};'>";
            echo "<td>{$result['status']}</td>";
            echo "<td>{$result['message']}</td>";
            echo "<td>";
            
            if (isset($result['expected']) && isset($result['actual'])) {
                echo "Expected: ";
                echo "<pre>" . print_r($result['expected'], true) . "</pre>";
                echo "Actual: ";
                echo "<pre>" . print_r($result['actual'], true) . "</pre>";
            }
            
            echo "</td>";
            echo "</tr>";
        }
        
        echo "</table>";
    }
    
    /**
     * Test newspaper creation functionality
     */
    public function testNewspaperCreation() {
        echo "<h2>Testing Newspaper Creation Functions</h2>";
        
        // Test 1: Empty required fields validation
        $this->testEmptyRequiredFieldsNewspaperCreate();
        
        // Test 2: Successful newspaper creation
        $this->testSuccessfulNewspaperCreate();

        // Test 3: Database error
        $this->testDatabaseErrorNewspaperCreate();
    }
    
    /**
     * Test empty required fields in newspaper creation
     */
    private function testEmptyRequiredFieldsNewspaperCreate() {
        // Set up mock with no data
        $this->setUp(null);
        
        // Call the processNewspaperCreate function directly with empty surname and forename
        $result = processNewspaperCreate('', '', 'Corporal', 'London', 'Infantry', 'Unit A', 
                                      'Test comment', 'The Times', '1915-01-01', 'Page 5', 'No', $this->mockConn);
        
        // Check if the result is correct
        $this->assertEquals(
            ['success' => false, 'message' => "Surname and Forename are required!"],
            $result,
            "Empty required fields validation in newspaper creation"
        );
    }
    
    /**
     * Test successful newspaper creation
     */
    private function testSuccessfulNewspaperCreate() {
        // Set up mock with no existing newspaper
        $this->setUp(null);
        
        // Call the processNewspaperCreate function directly
        $result = processNewspaperCreate('Smith', 'John', 'Corporal', 'London', 'Infantry', 'Unit A', 
                                      'Test comment', 'The Times', '1915-01-01', 'Page 5', 'No', $this->mockConn);
        
        // Check if the result is correct
        $this->assertEquals(
            ['success' => true, 'message' => "Newspaper Ref created successfully!"],
            $result,
            "Successful newspaper creation"
        );
    }
    
    /**
     * Test database error during newspaper creation
     */
    private function testDatabaseErrorNewspaperCreate() {
        // Set up mock with no existing newspaper but with execute error
        $this->setUp(null);
        $this->mockConn->setExecuteResult(false);
        
        // Call the processNewspaperCreate function directly
        $result = processNewspaperCreate('Smith', 'John', 'Corporal', 'London', 'Infantry', 'Unit A', 
                                      'Test comment', 'The Times', '1915-01-01', 'Page 5', 'No', $this->mockConn);
        
        // Check if the result is correct
        $this->assertEquals(
            ['success' => false, 'message' => "Something went wrong!"],
            $result,
            "Database error during newspaper creation"
        );
    }
    
    /**
     * Test newspaper update functionality
     */
    public function testNewspaperUpdate() {
        echo "<h2>Testing Newspaper Update Functions</h2>";
        
        // Test 1: Invalid ID validation
        $this->testInvalidIdNewspaperUpdate();
        
        // Test 2: Empty required fields validation
        $this->testEmptyRequiredFieldsNewspaperUpdate();
        
        // Test 3: Successful newspaper update
        $this->testSuccessfulNewspaperUpdate();
        
        // Test 4: Database error
        $this->testDatabaseErrorNewspaperUpdate();
    }
    
    /**
     * Test invalid ID in newspaper update
     */
    private function testInvalidIdNewspaperUpdate() {
        // Set up mock with no data
        $this->setUp(null);
        
        // Call the processNewspaperUpdate function directly with non-integer ID
        $result = processNewspaperUpdate('abc', 'Smith', 'John', 'Corporal', 'London', 'Infantry', 'Unit A', 
                                      'Test comment', 'The Times', '1915-01-01', 'Page 5', 'No', $this->mockConn);
        
        // Check if the result is correct
        $this->assertEquals(
            ['success' => false, 'message' => "Invalid newspaper ID!"],
            $result,
            "Invalid ID validation in newspaper update"
        );
    }
    
    /**
     * Test empty required fields in newspaper update
     */
    private function testEmptyRequiredFieldsNewspaperUpdate() {
        // Set up mock with no data
        $this->setUp(null);
        
        // Call the processNewspaperUpdate function directly with empty surname and forename
        $result = processNewspaperUpdate(1, '', '', 'Corporal', 'London', 'Infantry', 'Unit A', 
                                      'Test comment', 'The Times', '1915-01-01', 'Page 5', 'No', $this->mockConn);
        
        // Check if the result is correct
        $this->assertEquals(
            ['success' => false, 'message' => "Surname and Forename are required!"],
            $result,
            "Empty required fields validation in newspaper update"
        );
    }
    
    /**
     * Test successful newspaper update
     */
    private function testSuccessfulNewspaperUpdate() {
        // Set up mock with no data
        $this->setUp(null);
        
        // Call the processNewspaperUpdate function directly
        $result = processNewspaperUpdate(1, 'Smith', 'John', 'Corporal', 'London', 'Infantry', 'Unit A', 
                                      'Test comment', 'The Times', '1915-01-01', 'Page 5', 'No', $this->mockConn);
        
        // Check if the result is correct
        $this->assertEquals(
            ['success' => true, 'message' => "Newspaper Ref updated successfully!"],
            $result,
            "Successful newspaper update"
        );
    }
    
    /**
     * Test database error during newspaper update
     */
    private function testDatabaseErrorNewspaperUpdate() {
        // Set up mock with execute error
        $this->setUp(null);
        $this->mockConn->setExecuteResult(false);
        
        // Call the processNewspaperUpdate function directly
        $result = processNewspaperUpdate(1, 'Smith', 'John', 'Corporal', 'London', 'Infantry', 'Unit A', 
                                      'Test comment', 'The Times', '1915-01-01', 'Page 5', 'No', $this->mockConn);
        
        // Check if the result is correct
        $this->assertEquals(
            ['success' => false, 'message' => "Something went wrong!"],
            $result,
            "Database error during newspaper update"
        );
    }
    
    /**
     * Test newspaper deletion functionality
     */
    public function testNewspaperDelete() {
        echo "<h2>Testing Newspaper Delete Functions</h2>";
        
        // Test 1: Invalid ID validation
        $this->testInvalidIdNewspaperDelete();
        
        // Test 2: Newspaper not found
        $this->testNewspaperNotFoundNewspaperDelete();
        
        // Test 3: Successful newspaper deletion
        $this->testSuccessfulNewspaperDelete();
        
        // Test 4: Database error
        $this->testDatabaseErrorNewspaperDelete();
    }
    
    /**
     * Test invalid ID validation in newspaper deletion
     */
    private function testInvalidIdNewspaperDelete() {
        // Set up mock with no data
        $this->setUp(null);
        
        // Call the processNewspaperDelete function directly with non-integer ID
        $result = processNewspaperDelete('abc', $this->mockConn);
        
        // Check if the result is correct
        $this->assertEquals(
            ['success' => false, 'message' => "Invalid newspaper ID!"],
            $result,
            "Invalid ID validation in newspaper deletion"
        );
    }
    
    /**
     * Test newspaper not found in newspaper deletion
     */
    private function testNewspaperNotFoundNewspaperDelete() {
        // Set up mock with no newspaper data
        $this->setUp(null);
        
        // Call the processNewspaperDelete function directly
        $result = processNewspaperDelete(999, $this->mockConn);
        
        // Check if the result is correct
        $this->assertEquals(
            ['success' => false, 'message' => "Newspaper not found!"],
            $result,
            "Newspaper not found in newspaper deletion"
        );
    }
    
    /**
     * Test successful newspaper deletion
     */
    private function testSuccessfulNewspaperDelete() {
        // Mock data for an existing newspaper
        $mockData = [
            'id' => 1,
            'Surname' => 'Smith',
            'Forename' => 'John',
            'Rank' => 'Corporal'
        ];
        
        // Set up mock with newspaper data
        $this->setUp($mockData);
        
        // Call the processNewspaperDelete function directly
        $result = processNewspaperDelete(1, $this->mockConn);
        
        // Check if the result is correct
        $this->assertEquals(
            ['success' => true, 'message' => "Newspaper Ref deleted successfully!"],
            $result,
            "Successful newspaper deletion"
        );
    }
    
    /**
     * Test database error during newspaper deletion
     */
    private function testDatabaseErrorNewspaperDelete() {
        // Mock data for an existing newspaper
        $mockData = [
            'id' => 1,
            'Surname' => 'Smith',
            'Forename' => 'John',
            'Rank' => 'Corporal'
        ];
        
        // Set up mock with newspaper data but with execute error
        $this->setUp($mockData);
        $this->mockConn->setExecuteResult(false);
        
        // Call the processNewspaperDelete function directly
        $result = processNewspaperDelete(1, $this->mockConn);
        
        // Check if the result is correct
        $this->assertEquals(
            ['success' => false, 'message' => "Something went wrong!"],
            $result,
            "Database error during newspaper deletion"
        );
    }
    
    /**
     * Test get newspaper by ID functionality
     */
    public function testGetNewspaperById() {
        echo "<h2>Testing Get Newspaper by ID Functions</h2>";
        
        // Test 1: Invalid ID validation
        $this->testInvalidIdGetNewspaperById();
        
        // Test 2: Newspaper not found
        $this->testNewspaperNotFoundGetNewspaperById();
        
        // Test 3: Successful retrieval
        $this->testSuccessfulGetNewspaperById();
    }
    
    /**
     * Test invalid ID validation in get newspaper by ID
     */
    private function testInvalidIdGetNewspaperById() {
        // Set up mock with no data
        $this->setUp(null);
        
        // Call the getNewspaperById function directly with non-integer ID
        $result = getNewspaperById('abc', $this->mockConn);
        
        // Check if the result is correct
        $this->assertEquals(
            null,
            $result,
            "Invalid ID validation in get newspaper by ID"
        );
    }
    
    /**
     * Test newspaper not found in get newspaper by ID
     */
    private function testNewspaperNotFoundGetNewspaperById() {
        // Set up mock with no newspaper data
        $this->setUp(null);
        
        // Call the getNewspaperById function directly
        $result = getNewspaperById(999, $this->mockConn);
        
        // Check if the result is correct
        $this->assertEquals(
            null,
            $result,
            "Newspaper not found in get newspaper by ID"
        );
    }
    
    /**
     * Test successful retrieval in get newspaper by ID
     */
    private function testSuccessfulGetNewspaperById() {
        // Mock data for an existing newspaper
        $mockData = [
            'id' => 1,
            'Surname' => 'Smith',
            'Forename' => 'John',
            'Rank' => 'Corporal',
            'Address' => 'London',
            'Regiment' => 'Infantry',
            'Unit' => 'Unit A'
        ];
        
        // Set up mock with newspaper data
        $this->setUp($mockData);
        
        // Call the getNewspaperById function directly
        $result = getNewspaperById(1, $this->mockConn);
        
        // Check if the result is correct
        $this->assertEquals(
            $mockData,
            $result,
            "Successful retrieval in get newspaper by ID"
        );
    }
    
    /**
     * Test get all newspapers functionality
     */
    public function testGetAllNewspapers() {
        echo "<h2>Testing Get All Newspapers Function</h2>";
        
        // Test 1: No newspapers found
        $this->testNoNewspapersFoundGetAllNewspapers();
        
        // Test 2: Multiple newspapers found
        $this->testMultipleNewspapersFoundGetAllNewspapers();
    }
    
    /**
     * Test no newspapers found in get all newspapers
     */
    private function testNoNewspapersFoundGetAllNewspapers() {
        // Set up mock with no newspapers
        $this->setUp([]);
        
        // Call the getAllNewspapers function directly
        $result = getAllNewspapers($this->mockConn);
        
        // Check if the result is correct
        $this->assertEquals(
            [],
            $result,
            "No newspapers found in get all newspapers"
        );
    }
    
    /**
     * Test multiple newspapers found in get all newspapers
     */
    private function testMultipleNewspapersFoundGetAllNewspapers() {
        // Mock data for multiple newspapers
        $mockData = [
            [
                'id' => 1,
                'Surname' => 'Smith',
                'Forename' => 'John',
                'Rank' => 'Corporal',
                'Address' => 'London'
            ],
            [
                'id' => 2,
                'Surname' => 'Jones',
                'Forename' => 'Robert',
                'Rank' => 'Private',
                'Address' => 'Manchester'
            ]
        ];
        
        // Set up mock with multiple newspapers
        $this->setUp($mockData);
        
        // Call the getAllNewspapers function directly
        $result = getAllNewspapers($this->mockConn);
        
        // Check if the result is correct
        $this->assertEquals(
            $mockData,
            $result,
            "Multiple newspapers found in get all newspapers"
        );
    }
}