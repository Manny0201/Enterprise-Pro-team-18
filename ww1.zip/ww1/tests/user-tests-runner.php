<?php
/**
 * User Tests Runner
 * 
 * This file runs the test cases for user management functions
 */

// Include the user tests file
require_once(__DIR__ . '/user-tests.php');

// Start output buffering for cleaner output
ob_start();

// Display page header
echo "<!DOCTYPE html>
<html lang='en'>
<head>
    <meta charset='UTF-8'>
    <meta name='viewport' content='width=device-width, initial-scale=1.0'>
    <title>User Management Tests</title>
     <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            line-height: 1.6;
        }
        h1 {
            color: #333;
            border-bottom: 2px solid #ddd;
            padding-bottom: 10px;
        }
        h2 {
            color: #444;
            margin-top: 30px;
            border-bottom: 1px solid #eee;
            padding-bottom: 5px;
        }
        table {
            border-collapse: collapse;
            width: 100%;
            margin-top: 20px;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 8px;
        }
        th {
            background-color: #f2f2f2;
            text-align: left;
        }
        .pass {
            background-color: #d4edda;
        }
        .fail {
            background-color: #f8d7da;
        }
        .test-selector {
            margin: 20px 0;
            padding: 15px;
            border: 1px solid #ddd;
            background: #f9f9f9;
            border-radius: 5px;
        }
        .test-selector h3 {
            margin-top: 0;
        }
        .test-selector label {
            display: block;
            margin: 10px 0;
        }
        .btn {
            padding: 8px 15px;
            background: #007bff;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        .btn:hover {
            background: #0069d9;
        }
    </style>
</head>
<body>
   ";

// Create a test instance
$userTests = new UserManagementTests();

// Run all tests
$userTests->runAllTests();

// Display page footer
echo "</body>
</html>";

// Flush the output buffer
ob_end_flush();