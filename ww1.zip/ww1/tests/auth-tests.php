<?php
// Authentication test suite for login.php, register.php, and change-password.php

session_start();

// Include auth functions if not already included
if (!function_exists('processLogin')) {
    require_once(__DIR__ . '/auth-functions.php');
}

// Add a wrapper function for password verification to avoid redeclaring the native function
if (!function_exists('verifyPassword')) {
    function verifyPassword($password, $hash) {
        // This wrapper will be used in tests
        // In real code, this would call the native password_verify()
        return $GLOBALS['password_verify_result'];
    }
}

class MockDatabaseConnector {
    private $mockResult;
    private $lastQuery = '';
    private $lastParams = [];
  
    public function __construct() {
        $this->mockResult = null;
    }
  
    public function setMockResult($result) {
        $this->mockResult = $result;
    }
  
    public function prepare($query) {
        $this->lastQuery = $query;
        return new MockStatement($this->mockResult, $this);
    }
    
    public function setLastParams($params) {
        $this->lastParams = $params;
    }
    
    public function getLastQuery() {
        return $this->lastQuery;
    }
    
    public function getLastParams() {
        return $this->lastParams;
    }
}

// Create a mock statement class
class MockStatement {
    private $mockResult;
    private $mockConn;
    private $params = [];
  
    public function __construct($mockResult, $mockConn) {
        $this->mockResult = $mockResult;
        $this->mockConn = $mockConn;
    }
  
    public function bind_param($types, ...$params) {
        $this->params = $params;
        $this->mockConn->setLastParams($params);
        return true;
    }
  
    public function execute() {
        return true;
    }
  
    public function get_result() {
        return new MockResult($this->mockResult);
    }
}

// Create a mock result class
class MockResult {
    private $mockData;
    private $returned = false;
  
    public function __construct($mockData) {
        $this->mockData = $mockData;
    }
  
    public function fetch_assoc() {
        // Return the data once, then null to simulate end of results
        if (!$this->returned && $this->mockData !== null) {
            $this->returned = true;
            return $this->mockData;
        }
        return null;
    }
}

class AuthenticationTests {
    private $testsPassed = 0;
    private $testsFailed = 0;
    private $testResults = [];
    private $mockConn;
    
    /**
     * Set up mock connection and statement objects
     */
    public function setUp($mockData = null) {
        // Create mock database connector
        $this->mockConn = new MockDatabaseConnector();
        $this->mockConn->setMockResult($mockData);
        
        // Define global $conn to reference our mock
        global $conn;
        $conn = $this->mockConn;
        
        // Set the default password_verify result
        $GLOBALS['password_verify_result'] = false;
    }
    
    /**
     * Run all tests
     */
    public function runAllTests() {
        echo "<h1>Authentication Tests Suite</h1>";
        
        // Test register functionality
        $this->testRegistration();
        
        // Test login functionality
        $this->testLogin();
        
        // Test change password functionality
        $this->testChangePassword();
        
        // Display summary
        $this->displaySummary();
    }
    
    /**
     * Assert that two values are equal
     */
    private function assertEquals($expected, $actual, $message = "") {
        if ($expected === $actual) {
            $this->testsPassed++;
            $this->testResults[] = [
                'status' => 'PASS',
                'message' => $message,
                'expected' => $expected,
                'actual' => $actual
            ];
            return true;
        } else {
            $this->testsFailed++;
            $this->testResults[] = [
                'status' => 'FAIL',
                'message' => $message,
                'expected' => $expected,
                'actual' => $actual
            ];
            return false;
        }
    }
    
    /**
     * Assert that a condition is true
     */
    private function assertTrue($condition, $message = "") {
        if ($condition) {
            $this->testsPassed++;
            $this->testResults[] = [
                'status' => 'PASS',
                'message' => $message
            ];
            return true;
        } else {
            $this->testsFailed++;
            $this->testResults[] = [
                'status' => 'FAIL',
                'message' => $message
            ];
            return false;
        }
    }
    
    /**
     * Display test results
     */
    public function displaySummary() {
        echo "<h2>Test Results</h2>";
        echo "<div style='margin-bottom: 10px;'>";
        echo "<strong>Tests Passed:</strong> {$this->testsPassed}, ";
        echo "<strong>Tests Failed:</strong> {$this->testsFailed}";
        echo "</div>";
        
        echo "<table border='1' cellpadding='5' style='border-collapse: collapse; width: 100%;'>";
        echo "<tr style='background-color: #f2f2f2;'>";
        echo "<th>Status</th><th>Test</th><th>Details</th>";
        echo "</tr>";
        
        foreach ($this->testResults as $result) {
            $statusColor = $result['status'] === 'PASS' ? '#d4edda' : '#f8d7da';
            echo "<tr style='background-color: {$statusColor};'>";
            echo "<td>{$result['status']}</td>";
            echo "<td>{$result['message']}</td>";
            echo "<td>";
            
            if (isset($result['expected']) && isset($result['actual'])) {
                echo "Expected: " . var_export($result['expected'], true);
                echo "<br>Actual: " . var_export($result['actual'], true);
            }
            
            echo "</td>";
            echo "</tr>";
        }
        
        echo "</table>";
    }
    
    /**
     * Test registration functionality
     */
    public function testRegistration() {
        echo "<h2>Testing Registration Functions</h2>";
        
        // Test 1: Empty fields validation
        $this->testEmptyFieldsRegistration();
        
        // Test 2: Password match validation
        $this->testPasswordMatchRegistration();
        
        // Test 3: Email format validation
        $this->testEmailFormatRegistration();
        
        // Test 4: Password pattern validation
        $this->testPasswordPatternRegistration();
        
        // Test 5: Existing email or username
        $this->testExistingEmailOrUsername();
        
        // Test 6: Successful registration
        $this->testSuccessfulRegistration();
    }
    
    /**
     * Test empty fields in registration
     */
    private function testEmptyFieldsRegistration() {
        // Set up mock with no data
        $this->setUp(null);
        
        // Call the processRegistration function directly
        $result = processRegistration('', '', '', '', $this->mockConn);
        
        // Check if the result is correct
        $this->assertEquals(
            ['success' => false, 'message' => "Please fill all fields!"],
            $result,
            "Empty fields validation in registration"
        );
    }
    
    /**
     * Test password match validation in registration
     */
    private function testPasswordMatchRegistration() {
        // Set up mock with no data
        $this->setUp(null);
        
        // Call the processRegistration function directly
        $result = processRegistration('testuser', 'test@example.com', 'Password123', 'Password321', $this->mockConn);
        
        // Check if the result is correct
        $this->assertEquals(
            ['success' => false, 'message' => "Passwords do not match!"],
            $result,
            "Password match validation in registration"
        );
    }
    
    /**
     * Test email format validation in registration
     */
    private function testEmailFormatRegistration() {
        // Set up mock with no data
        $this->setUp(null);
        
        // Call the processRegistration function directly
        $result = processRegistration('testuser', 'invalid-email', 'Password123', 'Password123', $this->mockConn);
        
        // Check if the result is correct
        $this->assertEquals(
            ['success' => false, 'message' => "Use correct email format!"],
            $result,
            "Email format validation in registration"
        );
    }
    
    /**
     * Test password pattern validation in registration
     */
    private function testPasswordPatternRegistration() {
        // Set up mock with no data
        $this->setUp(null);
        
        // Call the processRegistration function directly
        $result = processRegistration('testuser', 'test@example.com', 'password', 'password', $this->mockConn);
        
        // Check if the result is correct
        $this->assertEquals(
            ['success' => false, 'message' => "Password must contain at least one number, one uppercase, one lowercase letter, and at least 8 or more characters!"],
            $result,
            "Password pattern validation in registration"
        );
    }
    
    /**
     * Test existing email or username validation
     */
    private function testExistingEmailOrUsername() {
        // Mock data for an existing user
        $mockData = [
            'id' => 1,
            'username' => 'existinguser',
            'email' => 'existing@example.com'
        ];
        
        // Set up mock with existing user data
        $this->setUp($mockData);
        
        // Call the processRegistration function directly
        $result = processRegistration('existinguser', 'existing@example.com', 'Password123', 'Password123', $this->mockConn);
        
        // Check if the result is correct
        $this->assertEquals(
            ['success' => false, 'message' => "Email or username already exists!"],
            $result,
            "Existing email or username validation"
        );
    }
    
    /**
     * Test successful registration
     */
    private function testSuccessfulRegistration() {
        // Set up mock with no existing user
        $this->setUp(null);
        
        // Call the processRegistration function directly
        $result = processRegistration('newuser', 'new@example.com', 'Password123', 'Password123', $this->mockConn);
        
        // Check if the result is correct
        $this->assertEquals(
            ['success' => true, 'message' => "User created successfully!"],
            $result,
            "Successful registration"
        );
    }
    
    /**
     * Test login functionality
     */
    public function testLogin() {
        echo "<h2>Testing Login Functions</h2>";
        
        // Test 1: Empty fields validation
        $this->testEmptyFieldsLogin();
        
        // Test 2: Username not found
        $this->testUsernameNotFound();
        
        // Test 3: Incorrect password
        $this->testIncorrectPassword();
        
        // Test 4: User locked out
        $this->testUserLockedOut();
        
        // Test 5: Successful login - user
        $this->testSuccessfulLoginUser();
        
        // Test 6: Successful login - admin
        $this->testSuccessfulLoginAdmin();
    }
    
    /**
     * Test empty fields in login
     */
    private function testEmptyFieldsLogin() {
        // Set up mock with no data
        $this->setUp(null);
        
        // Call the processLogin function directly
        $result = processLogin('', '', $this->mockConn);
        
        // Check if the result is correct
        $this->assertEquals(
            ['success' => false, 'message' => "Please fill all fields!"],
            $result,
            "Empty fields validation in login"
        );
    }
    
    /**
     * Test username not found in login
     */
    private function testUsernameNotFound() {
        // Set up mock with no user data
        $this->setUp(null);
        
        // Call the processLogin function directly
        $result = processLogin('nonexistent', 'Password123', $this->mockConn);
        
        // Check if the result is correct
        $this->assertEquals(
            ['success' => false, 'message' => "Username not found!"],
            $result,
            "Username not found in login"
        );
    }
    
    /**
     * Test incorrect password in login
     */
    private function testIncorrectPassword() {
        // Mock data for a user
        $mockData = [
            'id' => 1,
            'username' => 'testuser',
            'email' => 'test@example.com',
            'password' => password_hash('Password123', PASSWORD_DEFAULT),
            'failed_attempts' => 1,
            'lockout_time' => null,
            'role' => 'u'
        ];
        
        // Set up mock with user data
        $this->setUp($mockData);
        
        // Set password_verify to return false (incorrect password)
        $GLOBALS['password_verify_result'] = false;
        
        // Call the processLogin function directly
        $result = processLogin('testuser', 'WrongPassword', $this->mockConn);
        
        // Check if the result contains incorrect password message
        $this->assertTrue(
            $result['success'] === false && strpos($result['message'], "Incorrect password!") !== false,
            "Incorrect password in login"
        );
    }
    
    /**
     * Test user locked out in login
     */
    private function testUserLockedOut() {
        // Future lockout time
        $lockoutTime = date('Y-m-d H:i:s', strtotime("+5 minutes"));
        
        // Mock data for a locked out user
        $mockData = [
            'id' => 1,
            'username' => 'testuser',
            'email' => 'test@example.com',
            'password' => password_hash('Password123', PASSWORD_DEFAULT),
            'failed_attempts' => 3,
            'lockout_time' => $lockoutTime,
            'role' => 'u'
        ];
        
        // Set up mock with locked user data
        $this->setUp($mockData);
        
        // Call the processLogin function directly
        $result = processLogin('testuser', 'Password123', $this->mockConn);
        
        // Check if the result contains locked out message
        $this->assertTrue(
            $result['success'] === false && strpos($result['message'], "Too many failed login attempts") !== false,
            "User locked out in login"
        );
    }
    
    /**
     * Test successful login for normal user
     */
    private function testSuccessfulLoginUser() {
        // Mock data for a valid user
        $mockData = [
            'id' => 1,
            'username' => 'testuser',
            'email' => 'test@example.com',
            'password' => password_hash('Password123', PASSWORD_DEFAULT),
            'failed_attempts' => 0,
            'lockout_time' => null,
            'role' => 'u'
        ];
        
        // Set up mock with user data
        $this->setUp($mockData);
        
        // Set password_verify to return true (correct password)
        $GLOBALS['password_verify_result'] = true;
        
        // Call the processLogin function directly
        $result = processLogin('testuser', 'Password123', $this->mockConn);
        
        // Check if the result is correct for successful login
        $this->assertTrue(
            $result['success'] === true && 
            $result['userId'] === 1 && 
            $result['username'] === 'testuser' && 
            $result['userRole'] === 'u',
            "Successful login for normal user"
        );
    }
    
    /**
     * Test successful login for admin user
     */
    private function testSuccessfulLoginAdmin() {
        // Mock data for an admin user
        $mockData = [
            'id' => 2,
            'username' => 'admin',
            'email' => 'admin@example.com',
            'password' => password_hash('AdminPass123', PASSWORD_DEFAULT),
            'failed_attempts' => 0,
            'lockout_time' => null,
            'role' => 'a'
        ];
        
        // Set up mock with admin user data
        $this->setUp($mockData);
        
        // Set password_verify to return true (correct password)
        $GLOBALS['password_verify_result'] = true;
        
        // Call the processLogin function directly
        $result = processLogin('admin', 'AdminPass123', $this->mockConn);
        
        // Check if the result is correct for successful admin login
        $this->assertTrue(
            $result['success'] === true && 
            $result['userId'] === 2 && 
            $result['username'] === 'admin' && 
            $result['userRole'] === 'a',
            "Successful login for admin user"
        );
    }
    
    /**
     * Test change password functionality
     */
    public function testChangePassword() {
        echo "<h2>Testing Change Password Functions</h2>";
        
        // Test 1: Empty fields validation
        $this->testEmptyFieldsChangePassword();
        
        // Test 2: Password match validation
        $this->testPasswordMatchChangePassword();
        
        // Test 3: Password pattern validation
        $this->testPasswordPatternChangePassword();
        
        // Test 4: Old password verification
        $this->testOldPasswordVerification();
        
        // Test 5: Successful password change
        $this->testSuccessfulPasswordChange();
    }
    
    /**
     * Test empty fields in change password
     */
    private function testEmptyFieldsChangePassword() {
        // Set up mock with no data
        $this->setUp(null);
        
        // Call the processChangePassword function directly
        $result = processChangePassword(1, '', '', '', $this->mockConn);
        
        // Check if the result is correct
        $this->assertEquals(
            ['success' => false, 'message' => "Please fill all fields!"],
            $result,
            "Empty fields validation in change password"
        );
    }
    
    /**
     * Test password match validation in change password
     */
    private function testPasswordMatchChangePassword() {
        // Set up mock with no data
        $this->setUp(null);
        
        // Call the processChangePassword function directly
        $result = processChangePassword(
            1, 'Password123', 'NewPassword123', 'DifferentPassword123', $this->mockConn
        );
        
        // Check if the result is correct
        $this->assertEquals(
            ['success' => false, 'message' => "Passwords do not match!"],
            $result,
            "Password match validation in change password"
        );
    }
    
    /**
     * Test password pattern validation in change password
     */
    private function testPasswordPatternChangePassword() {
        // Set up mock with no data
        $this->setUp(null);
        
        // Call the processChangePassword function directly
        $result = processChangePassword(1, 'Password123', 'weakpass', 'weakpass', $this->mockConn);
        
        // Check if the result is correct
        $this->assertEquals(
            ['success' => false, 'message' => "Password must contain at least one number, one uppercase, one lowercase letter, and at least 8 or more characters!"],
            $result,
            "Password pattern validation in change password"
        );
    }
    
    /**
     * Test old password verification
     */
    private function testOldPasswordVerification() {
        // Mock data for a user
        $mockData = [
            'id' => 1,
            'username' => 'testuser',
            'email' => 'test@example.com',
            'password' => password_hash('Password123', PASSWORD_DEFAULT)
        ];
        
        // Set up mock with user data
        $this->setUp($mockData);
        
        // Set password_verify to return false (incorrect old password)
        $GLOBALS['password_verify_result'] = false;
        
        // Call the processChangePassword function directly
        $result = processChangePassword(
            1, 'WrongOldPassword', 'NewPassword123', 'NewPassword123', $this->mockConn
        );
        
        // Check if the result is correct
        $this->assertEquals(
            ['success' => false, 'message' => "Password does not match with our records!"],
            $result,
            "Old password verification"
        );
    }
    
    /**
     * Test successful password change
     */
    private function testSuccessfulPasswordChange() {
        // Mock data for a user
        $mockData = [
            'id' => 1,
            'username' => 'testuser',
            'email' => 'test@example.com',
            'password' => password_hash('Password123', PASSWORD_DEFAULT)
        ];
        
        // Set up mock with user data
        $this->setUp($mockData);
        
        // Set password_verify to return true (correct old password)
        $GLOBALS['password_verify_result'] = true;
        
        // Call the processChangePassword function directly
        $result = processChangePassword(
            1, 'Password123', 'NewPassword123', 'NewPassword123', $this->mockConn
        );
        
        // Check if the result is correct
        $this->assertEquals(
            ['success' => true, 'message' => "Password updated successfully!"],
            $result,
            "Successful password change"
        );
    }
}

// Run the tests if this file is being executed directly
if (basename($_SERVER['SCRIPT_FILENAME']) === basename(__FILE__)) {
    $tester = new AuthenticationTests();
    $tester->runAllTests();
}
?>