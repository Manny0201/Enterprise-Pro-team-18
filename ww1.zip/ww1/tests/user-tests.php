<?php
// user-tests.php - Test cases for the user management functions

// Include user functions if not already included
if (!function_exists('processUserCreate')) {
    require_once(__DIR__ . '/user-functions.php');
}

// Mock database classes similar to the auth test suite
class MockDatabaseConnector {
    private $mockResult;
    private $lastQuery = '';
    private $lastParams = [];
    private $executeResult = true;
  
    public function __construct() {
        $this->mockResult = null;
    }
  
    public function setMockResult($result) {
        $this->mockResult = $result;
    }

    public function setExecuteResult($result) {
        $this->executeResult = $result;
    }
  
    public function prepare($query) {
        $this->lastQuery = $query;
        return new MockStatement($this->mockResult, $this, $this->executeResult);
    }
    
    public function setLastParams($params) {
        $this->lastParams = $params;
    }
    
    public function getLastQuery() {
        return $this->lastQuery;
    }
    
    public function getLastParams() {
        return $this->lastParams;
    }
}

class MockStatement {
    private $mockResult;
    private $mockConn;
    private $params = [];
    private $executeResult = true;
  
    public function __construct($mockResult, $mockConn, $executeResult = true) {
        $this->mockResult = $mockResult;
        $this->mockConn = $mockConn;
        $this->executeResult = $executeResult;
    }
  
    public function bind_param($types, ...$params) {
        $this->params = $params;
        $this->mockConn->setLastParams($params);
        return true;
    }
  
    public function execute() {
        return $this->executeResult;
    }
  
    public function get_result() {
        return new MockResult($this->mockResult);
    }
}

class MockResult {
    private $mockData;
    private $index = 0;
    public $num_rows = 0;
  
    public function __construct($mockData) {
        $this->mockData = $mockData;
        
        if (is_array($mockData)) {
            if (isset($mockData[0]) && is_array($mockData[0])) {
                // Array of rows
                $this->num_rows = count($mockData);
            } elseif (!empty($mockData)) {
                // Single row
                $this->num_rows = 1;
                $this->mockData = [$mockData];
            }
        }
    }
  
    public function fetch_assoc() {
        if ($this->mockData === null || $this->index >= $this->num_rows) {
            return null;
        }
        
        if (isset($this->mockData[$this->index])) {
            return $this->mockData[$this->index++];
        }
        
        return null;
    }
}

class UserManagementTests {
    private $testsPassed = 0;
    private $testsFailed = 0;
    private $testResults = [];
    private $mockConn;
    
    /**
     * Set up mock connection and statement objects
     */
    public function setUp($mockData = null) {
        // Create mock database connector
        $this->mockConn = new MockDatabaseConnector();
        $this->mockConn->setMockResult($mockData);
        
        // Define global $conn to reference our mock
        global $conn;
        $conn = $this->mockConn;
    }
    
    /**
     * Run all tests
     */
    public function runAllTests() {
        echo "<h1>User Management Tests Suite</h1>";
        
        // Test user creation functionality
        $this->testUserCreation();
        
        // Test user update functionality
        $this->testUserUpdate();
        
        // Test user deletion functionality
        $this->testUserDelete();
        
        // Test get user by ID
        $this->testGetUserById();
        
        // Test get all users
        $this->testGetAllUsers();
        
        // Display summary
        $this->displaySummary();
    }
    
    /**
     * Assert that two values are equal
     */
    private function assertEquals($expected, $actual, $message = "") {
        if ($expected === $actual) {
            $this->testsPassed++;
            $this->testResults[] = [
                'status' => 'PASS',
                'message' => $message,
                'expected' => $expected,
                'actual' => $actual
            ];
            return true;
        } else {
            $this->testsFailed++;
            $this->testResults[] = [
                'status' => 'FAIL',
                'message' => $message,
                'expected' => $expected,
                'actual' => $actual
            ];
            return false;
        }
    }
    
    /**
     * Assert that a condition is true
     */
    private function assertTrue($condition, $message = "") {
        if ($condition) {
            $this->testsPassed++;
            $this->testResults[] = [
                'status' => 'PASS',
                'message' => $message
            ];
            return true;
        } else {
            $this->testsFailed++;
            $this->testResults[] = [
                'status' => 'FAIL',
                'message' => $message
            ];
            return false;
        }
    }
    
    /**
     * Display test results
     */
    public function displaySummary() {
        echo "<h2>Test Results</h2>";
        echo "<div style='margin-bottom: 10px;'>";
        echo "<strong>Tests Passed:</strong> {$this->testsPassed}, ";
        echo "<strong>Tests Failed:</strong> {$this->testsFailed}";
        echo "</div>";
        
        echo "<table border='1' cellpadding='5' style='border-collapse: collapse; width: 100%;'>";
        echo "<tr style='background-color: #f2f2f2;'>";
        echo "<th>Status</th><th>Test</th><th>Details</th>";
        echo "</tr>";
        
        foreach ($this->testResults as $result) {
            $statusColor = $result['status'] === 'PASS' ? '#d4edda' : '#f8d7da';
            echo "<tr style='background-color: {$statusColor};'>";
            echo "<td>{$result['status']}</td>";
            echo "<td>{$result['message']}</td>";
            echo "<td>";
            
            if (isset($result['expected']) && isset($result['actual'])) {
                echo "Expected: ";
                echo "<pre>" . print_r($result['expected'], true) . "</pre>";
                echo "Actual: ";
                echo "<pre>" . print_r($result['actual'], true) . "</pre>";
            }
            
            echo "</td>";
            echo "</tr>";
        }
        
        echo "</table>";
    }
    
    /**
     * Test user creation functionality
     */
    public function testUserCreation() {
        echo "<h2>Testing User Creation Functions</h2>";
        
        // Test 1: Empty fields validation
        $this->testEmptyFieldsUserCreate();
        
        // Test 2: Password match validation
        $this->testPasswordMatchUserCreate();
        
        // Test 3: Email format validation
        $this->testEmailFormatUserCreate();
        
        // Test 4: Password pattern validation
        $this->testPasswordPatternUserCreate();
        
        // Test 5: Existing email
        $this->testExistingEmailUserCreate();
        
        // Test 6: Successful user creation
        $this->testSuccessfulUserCreate();

        // Test 7: Database error
        $this->testDatabaseErrorUserCreate();
    }
    
    /**
     * Test empty fields in user creation
     */
    private function testEmptyFieldsUserCreate() {
        // Set up mock with no data
        $this->setUp(null);
        
        // Call the processUserCreate function directly
        $result = processUserCreate('', '', '', '', $this->mockConn);
        
        // Check if the result is correct
        $this->assertEquals(
            ['success' => false, 'message' => "Please fill all fields!"],
            $result,
            "Empty fields validation in user creation"
        );
    }
    
    /**
     * Test password match validation in user creation
     */
    private function testPasswordMatchUserCreate() {
        // Set up mock with no data
        $this->setUp(null);
        
        // Call the processUserCreate function directly
        $result = processUserCreate('testuser', 'test@example.com', 'Password123', 'Password321', $this->mockConn);
        
        // Check if the result is correct
        $this->assertEquals(
            ['success' => false, 'message' => "Passwords do not match!"],
            $result,
            "Password match validation in user creation"
        );
    }
    
    /**
     * Test email format validation in user creation
     */
    private function testEmailFormatUserCreate() {
        // Set up mock with no data
        $this->setUp(null);
        
        // Call the processUserCreate function directly
        $result = processUserCreate('testuser', 'invalid-email', 'Password123', 'Password123', $this->mockConn);
        
        // Check if the result is correct
        $this->assertEquals(
            ['success' => false, 'message' => "Use correct email format!"],
            $result,
            "Email format validation in user creation"
        );
    }
    
    /**
     * Test password pattern validation in user creation
     */
    private function testPasswordPatternUserCreate() {
        // Set up mock with no data
        $this->setUp(null);
        
        // Call the processUserCreate function directly
        $result = processUserCreate('testuser', 'test@example.com', 'password', 'password', $this->mockConn);
        
        // Check if the result is correct
        $this->assertEquals(
            ['success' => false, 'message' => "Password must contain at least one number, one uppercase, one lowercase letter, and at least 8 or more characters!"],
            $result,
            "Password pattern validation in user creation"
        );
    }
    
    /**
     * Test existing email validation
     */
    private function testExistingEmailUserCreate() {
        // Mock data for an existing user
        $mockData = [
            'id' => 1,
            'username' => 'existinguser',
            'email' => 'existing@example.com'
        ];
        
        // Set up mock with existing user data
        $this->setUp($mockData);
        
        // Call the processUserCreate function directly
        $result = processUserCreate('newuser', 'existing@example.com', 'Password123', 'Password123', $this->mockConn);
        
        // Check if the result is correct
        $this->assertEquals(
            ['success' => false, 'message' => "Email already exists!"],
            $result,
            "Existing email validation in user creation"
        );
    }
    
    /**
     * Test successful user creation
     */
    private function testSuccessfulUserCreate() {
        // Set up mock with no existing user
        $this->setUp(null);
        
        // Mock file data
        $fileData = [
            'name' => 'test.jpg',
            'tmp_name' => '/tmp/test.jpg',
            'size' => 1024,
            'error' => 0,
            'type' => 'image/jpeg'
        ];
        
        // Call the processUserCreate function directly
        $result = processUserCreate('newuser', 'new@example.com', 'Password123', 'Password123', $this->mockConn, $fileData);
        
        // Check if the result is correct
        $this->assertEquals(
            ['success' => true, 'message' => "User created successfully!"],
            $result,
            "Successful user creation"
        );
    }
    
    /**
     * Test database error during user creation
     */
    private function testDatabaseErrorUserCreate() {
        // Set up mock with no existing user but with execute error
        $this->setUp(null);
        $this->mockConn->setExecuteResult(false);
        
        // Call the processUserCreate function directly
        $result = processUserCreate('newuser', 'new@example.com', 'Password123', 'Password123', $this->mockConn);
        
        // Check if the result is correct
        $this->assertEquals(
            ['success' => false, 'message' => "Something went wrong!"],
            $result,
            "Database error during user creation"
        );
    }
    
    /**
     * Test user update functionality
     */
    public function testUserUpdate() {
        echo "<h2>Testing User Update Functions</h2>";
        
        // Test 1: Empty fields validation
        $this->testEmptyFieldsUserUpdate();
        
        // Test 2: Email format validation
        $this->testEmailFormatUserUpdate();
        
        // Test 3: Existing email
        $this->testExistingEmailUserUpdate();
        
        // Test 4: Successful user update without image
        $this->testSuccessfulUserUpdateNoImage();
        
        // Test 5: Successful user update with image
        $this->testSuccessfulUserUpdateWithImage();
        
        // Test 6: Database error
        $this->testDatabaseErrorUserUpdate();
    }
    
    /**
     * Test empty fields in user update
     */
    private function testEmptyFieldsUserUpdate() {
        // Set up mock with no data
        $this->setUp(null);
        
        // Call the processUserUpdate function directly
        $result = processUserUpdate('', '', '', '', $this->mockConn);
        
        // Check if the result is correct
        $this->assertEquals(
            ['success' => false, 'message' => "Please fill all fields!"],
            $result,
            "Empty fields validation in user update"
        );
    }
    
    /**
     * Test email format validation in user update
     */
    private function testEmailFormatUserUpdate() {
        // Set up mock with no data
        $this->setUp(null);
        
        // Call the processUserUpdate function directly
        $result = processUserUpdate(1, 'testuser', 'invalid-email', '', $this->mockConn);
        
        // Check if the result is correct
        $this->assertEquals(
            ['success' => false, 'message' => "Use correct email format!"],
            $result,
            "Email format validation in user update"
        );
    }
    
    /**
     * Test existing email validation in user update
     */
    private function testExistingEmailUserUpdate() {
        // Mock data for an existing user
        $mockData = [
            'id' => 2,
            'username' => 'existinguser',
            'email' => 'existing@example.com'
        ];
        
        // Set up mock with existing user data
        $this->setUp($mockData);
        
        // Call the processUserUpdate function directly
        $result = processUserUpdate(1, 'updateduser', 'existing@example.com', '', $this->mockConn);
        
        // Check if the result is correct
        $this->assertEquals(
            ['success' => false, 'message' => "Email already exists!"],
            $result,
            "Existing email validation in user update"
        );
    }
    
    /**
     * Test successful user update without changing image
     */
    private function testSuccessfulUserUpdateNoImage() {
        // Set up mock with no existing user with that email
        $this->setUp(null);
        
        // Call the processUserUpdate function directly
        $result = processUserUpdate(1, 'updateduser', 'updated@example.com', 'old_image.jpg', $this->mockConn);
        
        // Check if the result is correct
        $this->assertEquals(
            ['success' => true, 'message' => "User updated successfully!"],
            $result,
            "Successful user update without image change"
        );
    }
    
    /**
     * Test successful user update with image change
     */
    private function testSuccessfulUserUpdateWithImage() {
        // Set up mock with no existing user with that email
        $this->setUp(null);
        
        // Mock file data
        $fileData = [
            'name' => 'new.jpg',
            'tmp_name' => '/tmp/new.jpg',
            'size' => 1024,
            'error' => 0,
            'type' => 'image/jpeg'
        ];
        
        // Call the processUserUpdate function directly
        $result = processUserUpdate(1, 'updateduser', 'updated@example.com', 'old_image.jpg', $this->mockConn, $fileData);
        
        // Check if the result is correct
        $this->assertEquals(
            ['success' => true, 'message' => "User updated successfully!"],
            $result,
            "Successful user update with image change"
        );
    }
    
    /**
     * Test database error during user update
     */
    private function testDatabaseErrorUserUpdate() {
        // Set up mock with no existing user but with execute error
        $this->setUp(null);
        $this->mockConn->setExecuteResult(false);
        
        // Call the processUserUpdate function directly
        $result = processUserUpdate(1, 'updateduser', 'updated@example.com', 'old_image.jpg', $this->mockConn);
        
        // Check if the result is correct
        $this->assertEquals(
            ['success' => false, 'message' => "Something went wrong!"],
            $result,
            "Database error during user update"
        );
    }
    
    /**
     * Test user deletion functionality
     */
    public function testUserDelete() {
        echo "<h2>Testing User Delete Functions</h2>";
        
        // Test 1: Invalid ID validation
        $this->testInvalidIdUserDelete();
        
        // Test 2: User not found
        $this->testUserNotFoundUserDelete();
        
        // Test 3: Successful user deletion
        $this->testSuccessfulUserDelete();
        
        // Test 4: Database error
        $this->testDatabaseErrorUserDelete();
    }
    
    /**
     * Test invalid ID validation in user deletion
     */
    private function testInvalidIdUserDelete() {
        // Set up mock with no data
        $this->setUp(null);
        
        // Call the processUserDelete function directly with non-integer ID
        $result = processUserDelete('abc', $this->mockConn);
        
        // Check if the result is correct
        $this->assertEquals(
            ['success' => false, 'message' => "Invalid user ID!"],
            $result,
            "Invalid ID validation in user deletion"
        );
    }
    
    /**
     * Test user not found in user deletion
     */
    private function testUserNotFoundUserDelete() {
        // Set up mock with no user data
        $this->setUp(null);
        
        // Call the processUserDelete function directly
        $result = processUserDelete(999, $this->mockConn);
        
        // Check if the result is correct
        $this->assertEquals(
            ['success' => false, 'message' => "User not found!"],
            $result,
            "User not found in user deletion"
        );
    }
    
    /**
     * Test successful user deletion
     */
    private function testSuccessfulUserDelete() {
        // Mock data for an existing user
        $mockData = [
            'id' => 1,
            'username' => 'testuser',
            'email' => 'test@example.com',
            'image' => 'user_image.jpg'
        ];
        
        // Set up mock with user data
        $this->setUp($mockData);
        
        // Call the processUserDelete function directly
        $result = processUserDelete(1, $this->mockConn);
        
        // Check if the result is correct
        $this->assertEquals(
            ['success' => true, 'message' => "User deleted successfully!"],
            $result,
            "Successful user deletion"
        );
    }
    
    /**
     * Test database error during user deletion
     */
    private function testDatabaseErrorUserDelete() {
        // Mock data for an existing user
        $mockData = [
            'id' => 1,
            'username' => 'testuser',
            'email' => 'test@example.com'
        ];
        
        // Set up mock with user data but with execute error
        $this->setUp($mockData);
        $this->mockConn->setExecuteResult(false);
        
        // Call the processUserDelete function directly
        $result = processUserDelete(1, $this->mockConn);
        
        // Check if the result is correct
        $this->assertEquals(
            ['success' => false, 'message' => "Something went wrong!"],
            $result,
            "Database error during user deletion"
        );
    }
    
    /**
     * Test get user by ID functionality
     */
    public function testGetUserById() {
        echo "<h2>Testing Get User by ID Functions</h2>";
        
        // Test 1: Invalid ID validation
        $this->testInvalidIdGetUserById();
        
        // Test 2: User not found
        $this->testUserNotFoundGetUserById();
        
        // Test 3: Successful retrieval
        $this->testSuccessfulGetUserById();
    }
    
    /**
     * Test invalid ID validation in get user by ID
     */
    private function testInvalidIdGetUserById() {
        // Set up mock with no data
        $this->setUp(null);
        
        // Call the getUserById function directly with non-integer ID
        $result = getUserById('abc', $this->mockConn);
        
        // Check if the result is correct
        $this->assertEquals(
            null,
            $result,
            "Invalid ID validation in get user by ID"
        );
    }
    
    /**
     * Test user not found in get user by ID
     */
    private function testUserNotFoundGetUserById() {
        // Set up mock with no user data
        $this->setUp(null);
        
        // Call the getUserById function directly
        $result = getUserById(999, $this->mockConn);
        
        // Check if the result is correct
        $this->assertEquals(
            null,
            $result,
            "User not found in get user by ID"
        );
    }
    
    /**
     * Test successful retrieval in get user by ID
     */
    private function testSuccessfulGetUserById() {
        // Mock data for an existing user
        $mockData = [
            'id' => 1,
            'username' => 'testuser',
            'email' => 'test@example.com',
            'role' => 'u',
            'created_at' => '2025-04-01 12:00:00'
        ];
        
        // Set up mock with user data
        $this->setUp($mockData);
        
        // Call the getUserById function directly
        $result = getUserById(1, $this->mockConn);
        
        // Check if the result is correct
        $this->assertEquals(
            $mockData,
            $result,
            "Successful retrieval in get user by ID"
        );
    }
    
    /**
     * Test get all users functionality
     */
    public function testGetAllUsers() {
      echo "<h2>Testing Get All Users Function</h2>";
      
      // Test 1: No users found
      $this->testNoUsersFoundGetAllUsers();
      
      // Test 2: Multiple users found
      $this->testMultipleUsersFoundGetAllUsers();
  }
  
  /**
   * Test no users found in get all users
   */
  private function testNoUsersFoundGetAllUsers() {
      // Set up mock with no users
      $this->setUp([]);
      
      // Call the getAllUsers function directly
      $result = getAllUsers($this->mockConn);
      
      // Check if the result is correct
      $this->assertEquals(
          [],
          $result,
          "No users found in get all users"
      );
  }
  
  /**
   * Test multiple users found in get all users
   */
  private function testMultipleUsersFoundGetAllUsers() {
      // Mock data for multiple users
      $mockData = [
          [
              'id' => 1,
              'username' => 'user1',
              'email' => 'user1@example.com',
              'role' => 'u',
              'created_at' => '2025-04-01 12:00:00'
          ],
          [
              'id' => 2,
              'username' => 'user2',
              'email' => 'user2@example.com',
              'role' => 'u',
              'created_at' => '2025-04-02 12:00:00'
          ]
      ];
      
      // Set up mock with multiple users
      $this->setUp($mockData);
      
      // Call the getAllUsers function directly
      $result = getAllUsers($this->mockConn);
      
      // Check if the result is correct
      $this->assertEquals(
          $mockData,
          $result,
          "Multiple users found in get all users"
      );
  }
}