<?php
/**
 * Biography Functions
 * 
 * Functions for managing biography records in the database
 */

/**
 * Process biography creation
 * 
 * @param string $surname The surname
 * @param string $forename The forename
 * @param string $regiment The regiment
 * @param string $serviceNo The service number
 * @param string $attachment The biography attachment
 * @param object $dbConn Database connection object
 * @return array Result with success status and message
 */
function processBiographyCreate($surname, $forename, $regiment, $serviceNo, $attachment, $dbConn) {
    // Check for empty required fields
    if (empty($surname) || empty($forename)) {
        return ['success' => false, 'message' => "Please fill all required fields!"];
    }
    
    // SQL query to insert a new biography record
    $sql = "INSERT INTO biography_spreadsheet 
        (Surname, Forename, Regiment, `Service Number`, `Biography attachment`) 
        VALUES (?, ?, ?, ?, ?)";

    $stmt = $dbConn->prepare($sql);
    $stmt->bind_param("sssss", $surname, $forename, $regiment, $serviceNo, $attachment);

    if ($stmt->execute()) {
        return ['success' => true, 'message' => "Biography created successfully!"];
    } else {
        return ['success' => false, 'message' => "Something went wrong!"];
    }
}

/**
 * Process biography update
 * 
 * @param int $id The biography ID
 * @param string $surname The surname
 * @param string $forename The forename
 * @param string $regiment The regiment
 * @param string $serviceNo The service number
 * @param string $attachment The biography attachment
 * @param object $dbConn Database connection object
 * @return array Result with success status and message
 */
function processBiographyUpdate($id, $surname, $forename, $regiment, $serviceNo, $attachment, $dbConn) {
    // Validate ID
    if (!filter_var($id, FILTER_VALIDATE_INT)) {
        return ['success' => false, 'message' => "Invalid biography ID!"];
    }
    
    // Check for empty required fields
    if (empty($surname) || empty($forename)) {
        return ['success' => false, 'message' => "Please fill all required fields!"];
    }
    
    // Check if biography exists
    $biography = getBiographyById($id, $dbConn);
    if (!$biography) {
        return ['success' => false, 'message' => "Biography not found!"];
    }
    
    // SQL query to update biography record
    $sql = "UPDATE biography_spreadsheet 
            SET Surname = ?, Forename = ?, Regiment = ?, `Service Number` = ?, `Biography attachment` = ?
            WHERE id = ?";

    $stmt = $dbConn->prepare($sql);
    $stmt->bind_param("sssssi", $surname, $forename, $regiment, $serviceNo, $attachment, $id);

    if ($stmt->execute()) {
        return ['success' => true, 'message' => "Biography updated successfully!"];
    } else {
        return ['success' => false, 'message' => "Something went wrong!"];
    }
}

/**
 * Process biography deletion
 * 
 * @param int $id The biography ID
 * @param object $dbConn Database connection object
 * @return array Result with success status and message
 */
function processBiographyDelete($id, $dbConn) {
    // Validate ID
    if (!filter_var($id, FILTER_VALIDATE_INT)) {
        return ['success' => false, 'message' => "Invalid biography ID!"];
    }
    
    // Check if biography exists
    $biography = getBiographyById($id, $dbConn);
    if (!$biography) {
        return ['success' => false, 'message' => "Biography not found!"];
    }
    
    // SQL statement to delete
    $sql = "DELETE FROM biography_spreadsheet WHERE id = ?";
    $stmt = $dbConn->prepare($sql);
    $stmt->bind_param("i", $id);
    
    if ($stmt->execute()) {
        return ['success' => true, 'message' => "Biography deleted successfully!"];
    } else {
        return ['success' => false, 'message' => "Something went wrong!"];
    }
}

/**
 * Get biography by ID
 * 
 * @param int $id The biography ID
 * @param object $dbConn Database connection object
 * @return array|null Biography data or null if not found
 */
function getBiographyById($id, $dbConn) {
    // Validate ID
    if (!filter_var($id, FILTER_VALIDATE_INT)) {
        return null;
    }
    
    // SQL statement to get biography record
    $sql = "SELECT * FROM biography_spreadsheet WHERE id = ?";
    $stmt = $dbConn->prepare($sql);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows == 0) {
        return null;
    }
    
    return $result->fetch_assoc();
}

/**
 * Get all biographies
 * 
 * @param object $dbConn Database connection object
 * @param int $limit Maximum number of records to return (default 20)
 * @return array List of biographies
 */
function getAllBiographies($dbConn, $limit = 20) {
    // SQL query to get all biographies
    $sql = "SELECT * FROM biography_spreadsheet ORDER BY id DESC LIMIT ?";
    $stmt = $dbConn->prepare($sql);
    $stmt->bind_param("i", $limit);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $biographies = [];
    
    while ($row = $result->fetch_assoc()) {
        $biographies[] = $row;
    }
    
    return $biographies;
}