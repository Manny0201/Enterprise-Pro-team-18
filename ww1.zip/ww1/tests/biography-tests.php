<?php
// biography-tests.php - Test cases for the biography management functions

// Include biography functions if not already included
if (!function_exists('processBiographyCreate')) {
    require_once(__DIR__ . '/biography-functions.php');
}


class MockDatabaseConnector {
  private $mockResult;
  private $lastQuery = '';
  private $lastParams = [];
  private $executeResult = true;

  public function __construct() {
      $this->mockResult = null;
  }

  public function setMockResult($result) {
      $this->mockResult = $result;
  }

  public function setExecuteResult($result) {
      $this->executeResult = $result;
  }

  public function prepare($query) {
      $this->lastQuery = $query;
      return new MockStatement($this->mockResult, $this, $this->executeResult);
  }
  
  public function setLastParams($params) {
      $this->lastParams = $params;
  }
  
  public function getLastQuery() {
      return $this->lastQuery;
  }
  
  public function getLastParams() {
      return $this->lastParams;
  }
}

class MockStatement {
  private $mockResult;
  private $mockConn;
  private $params = [];
  private $executeResult = true;

  public function __construct($mockResult, $mockConn, $executeResult = true) {
      $this->mockResult = $mockResult;
      $this->mockConn = $mockConn;
      $this->executeResult = $executeResult;
  }

  public function bind_param($types, ...$params) {
      $this->params = $params;
      $this->mockConn->setLastParams($params);
      return true;
  }

  public function execute() {
      return $this->executeResult;
  }

  public function get_result() {
      return new MockResult($this->mockResult);
  }
}

class MockResult {
  private $mockData;
  private $index = 0;
  public $num_rows = 0;

  public function __construct($mockData) {
      $this->mockData = $mockData;
      
      if (is_array($mockData)) {
          if (isset($mockData[0]) && is_array($mockData[0])) {
              // Array of rows
              $this->num_rows = count($mockData);
          } elseif (!empty($mockData)) {
              // Single row
              $this->num_rows = 1;
              $this->mockData = [$mockData];
          }
      }
  }

  public function fetch_assoc() {
      if ($this->mockData === null || $this->index >= $this->num_rows) {
          return null;
      }
      
      if (isset($this->mockData[$this->index])) {
          return $this->mockData[$this->index++];
      }
      
      return null;
  }
}


class BiographyManagementTests {
    private $testsPassed = 0;
    private $testsFailed = 0;
    private $testResults = [];
    private $mockConn;
    
    /**
     * Set up mock connection and statement objects
     */
    public function setUp($mockData = null) {
        // Create mock database connector
        $this->mockConn = new MockDatabaseConnector();
        $this->mockConn->setMockResult($mockData);
        
        // Define global $conn to reference our mock
        global $conn;
        $conn = $this->mockConn;
    }
    
    /**
     * Run all tests
     */
    public function runAllTests() {
        echo "<h1>Biography Management Tests Suite</h1>";
        
        // Test biography creation functionality
        $this->testBiographyCreation();
        
        // Test biography update functionality
        $this->testBiographyUpdate();
        
        // Test biography deletion functionality
        $this->testBiographyDelete();
        
        // Test get biography by ID
        $this->testGetBiographyById();
        
        // Test get all biographies
        $this->testGetAllBiographies();
        
        // Display summary
        $this->displaySummary();
    }
    
    /**
     * Assert that two values are equal
     */
    private function assertEquals($expected, $actual, $message = "") {
        if ($expected === $actual) {
            $this->testsPassed++;
            $this->testResults[] = [
                'status' => 'PASS',
                'message' => $message,
                'expected' => $expected,
                'actual' => $actual
            ];
            return true;
        } else {
            $this->testsFailed++;
            $this->testResults[] = [
                'status' => 'FAIL',
                'message' => $message,
                'expected' => $expected,
                'actual' => $actual
            ];
            return false;
        }
    }
    
    /**
     * Assert that a condition is true
     */
    private function assertTrue($condition, $message = "") {
        if ($condition) {
            $this->testsPassed++;
            $this->testResults[] = [
                'status' => 'PASS',
                'message' => $message
            ];
            return true;
        } else {
            $this->testsFailed++;
            $this->testResults[] = [
                'status' => 'FAIL',
                'message' => $message
            ];
            return false;
        }
    }
    
    /**
     * Display test results
     */
    public function displaySummary() {
        echo "<h2>Test Results</h2>";
        echo "<div style='margin-bottom: 10px;'>";
        echo "<strong>Tests Passed:</strong> {$this->testsPassed}, ";
        echo "<strong>Tests Failed:</strong> {$this->testsFailed}";
        echo "</div>";
        
        echo "<table border='1' cellpadding='5' style='border-collapse: collapse; width: 100%;'>";
        echo "<tr style='background-color: #f2f2f2;'>";
        echo "<th>Status</th><th>Test</th><th>Details</th>";
        echo "</tr>";
        
        foreach ($this->testResults as $result) {
            $statusColor = $result['status'] === 'PASS' ? '#d4edda' : '#f8d7da';
            echo "<tr style='background-color: {$statusColor};'>";
            echo "<td>{$result['status']}</td>";
            echo "<td>{$result['message']}</td>";
            echo "<td>";
            
            if (isset($result['expected']) && isset($result['actual'])) {
                echo "Expected: ";
                echo "<pre>" . print_r($result['expected'], true) . "</pre>";
                echo "Actual: ";
                echo "<pre>" . print_r($result['actual'], true) . "</pre>";
            }
            
            echo "</td>";
            echo "</tr>";
        }
        
        echo "</table>";
    }
    
    /**
     * Test biography creation functionality
     */
    public function testBiographyCreation() {
        echo "<h2>Testing Biography Creation Functions</h2>";
        
        // Test 1: Empty required fields validation
        $this->testEmptyFieldsBiographyCreate();
        
        // Test 2: Successful biography creation
        $this->testSuccessfulBiographyCreate();

        // Test 3: Database error
        $this->testDatabaseErrorBiographyCreate();
    }
    
    /**
     * Test empty fields in biography creation
     */
    private function testEmptyFieldsBiographyCreate() {
        // Set up mock with no data
        $this->setUp(null);
        
        // Call the processBiographyCreate function directly
        $result = processBiographyCreate('', '', 'Test Regiment', 'ABC123', 'attachment.pdf', $this->mockConn);
        
        // Check if the result is correct
        $this->assertEquals(
            ['success' => false, 'message' => "Please fill all required fields!"],
            $result,
            "Empty required fields validation in biography creation"
        );
    }
    
    /**
     * Test successful biography creation
     */
    private function testSuccessfulBiographyCreate() {
        // Set up mock with no existing biography
        $this->setUp(null);
        
        // Call the processBiographyCreate function directly
        $result = processBiographyCreate('Smith', 'John', 'Royal Navy', 'ABC123', 'smith_john.pdf', $this->mockConn);
        
        // Check if the result is correct
        $this->assertEquals(
            ['success' => true, 'message' => "Biography created successfully!"],
            $result,
            "Successful biography creation"
        );
    }
    
    /**
     * Test database error during biography creation
     */
    private function testDatabaseErrorBiographyCreate() {
        // Set up mock with no existing biography but with execute error
        $this->setUp(null);
        $this->mockConn->setExecuteResult(false);
        
        // Call the processBiographyCreate function directly
        $result = processBiographyCreate('Smith', 'John', 'Royal Navy', 'ABC123', 'smith_john.pdf', $this->mockConn);
        
        // Check if the result is correct
        $this->assertEquals(
            ['success' => false, 'message' => "Something went wrong!"],
            $result,
            "Database error during biography creation"
        );
    }
    
    /**
     * Test biography update functionality
     */
    public function testBiographyUpdate() {
        echo "<h2>Testing Biography Update Functions</h2>";
        
        // Test 1: Invalid ID validation
        $this->testInvalidIdBiographyUpdate();
        
        // Test 2: Empty required fields validation
        $this->testEmptyFieldsBiographyUpdate();
        
        // Test 3: Biography not found
        $this->testBiographyNotFoundBiographyUpdate();
        
        // Test 4: Successful biography update
        $this->testSuccessfulBiographyUpdate();
        
        // Test 5: Database error
        $this->testDatabaseErrorBiographyUpdate();
    }
    
    /**
     * Test invalid ID validation in biography update
     */
    private function testInvalidIdBiographyUpdate() {
        // Set up mock with no data
        $this->setUp(null);
        
        // Call the processBiographyUpdate function directly with non-integer ID
        $result = processBiographyUpdate('abc', 'Smith', 'John', 'Royal Navy', 'ABC123', 'smith_john.pdf', $this->mockConn);
        
        // Check if the result is correct
        $this->assertEquals(
            ['success' => false, 'message' => "Invalid biography ID!"],
            $result,
            "Invalid ID validation in biography update"
        );
    }
    
    /**
     * Test empty fields in biography update
     */
    private function testEmptyFieldsBiographyUpdate() {
        // Set up mock with no data
        $this->setUp(null);
        
        // Call the processBiographyUpdate function directly
        $result = processBiographyUpdate(1, '', 'John', 'Royal Navy', 'ABC123', 'smith_john.pdf', $this->mockConn);
        
        // Check if the result is correct
        $this->assertEquals(
            ['success' => false, 'message' => "Please fill all required fields!"],
            $result,
            "Empty required fields validation in biography update"
        );
    }
    
    /**
     * Test biography not found in biography update
     */
    private function testBiographyNotFoundBiographyUpdate() {
        // Set up mock with no biography data
        $this->setUp(null);
        
        // Call the processBiographyUpdate function directly
        $result = processBiographyUpdate(999, 'Smith', 'John', 'Royal Navy', 'ABC123', 'smith_john.pdf', $this->mockConn);
        
        // Check if the result is correct
        $this->assertEquals(
            ['success' => false, 'message' => "Biography not found!"],
            $result,
            "Biography not found in biography update"
        );
    }
    
    /**
     * Test successful biography update
     */
    private function testSuccessfulBiographyUpdate() {
        // Mock data for an existing biography
        $mockData = [
            'id' => 1,
            'Surname' => 'Smith',
            'Forename' => 'John',
            'Regiment' => 'Royal Navy',
            'Service Number' => 'ABC123',
            'Biography attachment' => 'smith_john.pdf'
        ];
        
        // Set up mock with existing biography data
        $this->setUp($mockData);
        
        // Call the processBiographyUpdate function directly
        $result = processBiographyUpdate(1, 'Smith', 'James', 'Royal Marines', 'XYZ789', 'smith_james.pdf', $this->mockConn);
        
        // Check if the result is correct
        $this->assertEquals(
            ['success' => true, 'message' => "Biography updated successfully!"],
            $result,
            "Successful biography update"
        );
    }
    
    /**
     * Test database error during biography update
     */
    private function testDatabaseErrorBiographyUpdate() {
        // Mock data for an existing biography
        $mockData = [
            'id' => 1,
            'Surname' => 'Smith',
            'Forename' => 'John',
            'Regiment' => 'Royal Navy',
            'Service Number' => 'ABC123',
            'Biography attachment' => 'smith_john.pdf'
        ];
        
        // Set up mock with existing biography data but with execute error
        $this->setUp($mockData);
        $this->mockConn->setExecuteResult(false);
        
        // Call the processBiographyUpdate function directly
        $result = processBiographyUpdate(1, 'Smith', 'James', 'Royal Marines', 'XYZ789', 'smith_james.pdf', $this->mockConn);
        
        // Check if the result is correct
        $this->assertEquals(
            ['success' => false, 'message' => "Something went wrong!"],
            $result,
            "Database error during biography update"
        );
    }
    
    /**
     * Test biography deletion functionality
     */
    public function testBiographyDelete() {
        echo "<h2>Testing Biography Delete Functions</h2>";
        
        // Test 1: Invalid ID validation
        $this->testInvalidIdBiographyDelete();
        
        // Test 2: Biography not found
        $this->testBiographyNotFoundBiographyDelete();
        
        // Test 3: Successful biography deletion
        $this->testSuccessfulBiographyDelete();
        
        // Test 4: Database error
        $this->testDatabaseErrorBiographyDelete();
    }
    
    /**
     * Test invalid ID validation in biography deletion
     */
    private function testInvalidIdBiographyDelete() {
        // Set up mock with no data
        $this->setUp(null);
        
        // Call the processBiographyDelete function directly with non-integer ID
        $result = processBiographyDelete('abc', $this->mockConn);
        
        // Check if the result is correct
        $this->assertEquals(
            ['success' => false, 'message' => "Invalid biography ID!"],
            $result,
            "Invalid ID validation in biography deletion"
        );
    }
    
    /**
     * Test biography not found in biography deletion
     */
    private function testBiographyNotFoundBiographyDelete() {
        // Set up mock with no biography data
        $this->setUp(null);
        
        // Call the processBiographyDelete function directly
        $result = processBiographyDelete(999, $this->mockConn);
        
        // Check if the result is correct
        $this->assertEquals(
            ['success' => false, 'message' => "Biography not found!"],
            $result,
            "Biography not found in biography deletion"
        );
    }
    
    /**
     * Test successful biography deletion
     */
    private function testSuccessfulBiographyDelete() {
        // Mock data for an existing biography
        $mockData = [
            'id' => 1,
            'Surname' => 'Smith',
            'Forename' => 'John',
            'Regiment' => 'Royal Navy',
            'Service Number' => 'ABC123',
            'Biography attachment' => 'smith_john.pdf'
        ];
        
        // Set up mock with biography data
        $this->setUp($mockData);
        
        // Call the processBiographyDelete function directly
        $result = processBiographyDelete(1, $this->mockConn);
        
        // Check if the result is correct
        $this->assertEquals(
            ['success' => true, 'message' => "Biography deleted successfully!"],
            $result,
            "Successful biography deletion"
        );
    }
    
    /**
     * Test database error during biography deletion
     */
    private function testDatabaseErrorBiographyDelete() {
        // Mock data for an existing biography
        $mockData = [
            'id' => 1,
            'Surname' => 'Smith',
            'Forename' => 'John',
            'Regiment' => 'Royal Navy',
            'Service Number' => 'ABC123',
            'Biography attachment' => 'smith_john.pdf'
        ];
        
        // Set up mock with biography data but with execute error
        $this->setUp($mockData);
        $this->mockConn->setExecuteResult(false);
        
        // Call the processBiographyDelete function directly
        $result = processBiographyDelete(1, $this->mockConn);
        
        // Check if the result is correct
        $this->assertEquals(
            ['success' => false, 'message' => "Something went wrong!"],
            $result,
            "Database error during biography deletion"
        );
    }
    
    /**
     * Test get biography by ID functionality
     */
    public function testGetBiographyById() {
        echo "<h2>Testing Get Biography by ID Function</h2>";
        
        // Test 1: Invalid ID validation
        $this->testInvalidIdGetBiographyById();
        
        // Test 2: Biography not found
        $this->testBiographyNotFoundGetBiographyById();
        
        // Test 3: Successful retrieval
        $this->testSuccessfulGetBiographyById();
    }
    
    /**
     * Test invalid ID validation in get biography by ID
     */
    private function testInvalidIdGetBiographyById() {
        // Set up mock with no data
        $this->setUp(null);
        
        // Call the getBiographyById function directly with non-integer ID
        $result = getBiographyById('abc', $this->mockConn);
        
        // Check if the result is correct
        $this->assertEquals(
            null,
            $result,
            "Invalid ID validation in get biography by ID"
        );
    }
    
    /**
     * Test biography not found in get biography by ID
     */
    private function testBiographyNotFoundGetBiographyById() {
        // Set up mock with no biography data
        $this->setUp(null);
        
        // Call the getBiographyById function directly
        $result = getBiographyById(999, $this->mockConn);
        
        // Check if the result is correct
        $this->assertEquals(
            null,
            $result,
            "Biography not found in get biography by ID"
        );
    }
    
    /**
     * Test successful retrieval in get biography by ID
     */
    private function testSuccessfulGetBiographyById() {
        // Mock data for an existing biography
        $mockData = [
            'id' => 1,
            'Surname' => 'Smith',
            'Forename' => 'John',
            'Regiment' => 'Royal Navy',
            'Service Number' => 'ABC123',
            'Biography attachment' => 'smith_john.pdf'
        ];
        
        // Set up mock with biography data
        $this->setUp($mockData);
        
        // Call the getBiographyById function directly
        $result = getBiographyById(1, $this->mockConn);
        
        // Check if the result is correct
        $this->assertEquals(
            $mockData,
            $result,
            "Successful retrieval in get biography by ID"
        );
    }
    
    /**
     * Test get all biographies functionality
     */
    public function testGetAllBiographies() {
        echo "<h2>Testing Get All Biographies Function</h2>";
        
        // Test 1: No biographies found
        $this->testNoBiographiesFoundGetAllBiographies();
        
        // Test 2: Multiple biographies found
        $this->testMultipleBiographiesFoundGetAllBiographies();
    }
    
    /**
     * Test no biographies found in get all biographies
     */
    private function testNoBiographiesFoundGetAllBiographies() {
        // Set up mock with no biographies
        $this->setUp([]);
        
        // Call the getAllBiographies function directly
        $result = getAllBiographies($this->mockConn);
        
        // Check if the result is correct
        $this->assertEquals(
            [],
            $result,
            "No biographies found in get all biographies"
        );
    }
    
    /**
     * Test multiple biographies found in get all biographies
     */
    private function testMultipleBiographiesFoundGetAllBiographies() {
        // Mock data for multiple biographies
        $mockData = [
            [
                'id' => 1,
                'Surname' => 'Smith',
                'Forename' => 'John',
                'Regiment' => 'Royal Navy',
                'Service Number' => 'ABC123',
                'Biography attachment' => 'smith_john.pdf'
            ],
            [
                'id' => 2,
                'Surname' => 'Johnson',
                'Forename' => 'Mike',
                'Regiment' => 'Royal Marines',
                'Service Number' => 'XYZ789',
                'Biography attachment' => 'johnson_mike.pdf'
            ]
        ];
        
        // Set up mock with multiple biographies
        $this->setUp($mockData);
        
        // Call the getAllBiographies function directly
        $result = getAllBiographies($this->mockConn);
        
        // Check if the result is correct
        $this->assertEquals(
            $mockData,
            $result,
            "Multiple biographies found in get all biographies"
        );
    }
}