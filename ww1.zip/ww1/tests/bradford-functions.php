<?php
// bradford-functions.php - Functions for the Bradford management system

/**
 * Process Bradford record creation
 * 
 * @param array $formData Array containing all Bradford record fields
 * @param object $conn Database connection object
 * @return array Result with success status and message
 */
function processBradfordCreate($formData, $conn) {
    // Validate required fields
    if (empty($formData['Surname']) || empty($formData['Forename'])) {
        return ['success' => false, 'message' => 'Please fill all required fields!'];
    }
    
    // SQL query to insert a new Bradford record
    $sql = "INSERT INTO bradford_and_surrounding_townships_great_war_roll_of_honour_2025 
        (Surname, Forename, Address, `Electoral Ward`, Town, Rank, Regiment, Unit, Company, Age, `Service No`, 
        `Other Regiment`, `Other Unit`, `Other Service No.`, Medals, `Enlistment date`, `Discharge date`, 
        `Death (in service) date`, `Misc Info Nroh`, `Cemetery/Memorial`, `Cemetery/Memorial Ref`, 
        `Cemetery/Memorial Country`, `Additional CWGC info`) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    $stmt = $conn->prepare($sql);
    
    if (!$stmt) {
        return ['success' => false, 'message' => 'Database prepare error!'];
    }
    
    $stmt->bind_param("sssssssssssssssssssssss", 
        $formData['Surname'], $formData['Forename'], $formData['Address'], $formData['Electoral_Ward'], 
        $formData['Town'], $formData['Rank'], $formData['Regiment'], $formData['Unit'], $formData['Company'], 
        $formData['Age'], $formData['Service_No'], $formData['Other_Regiment'], $formData['Other_Unit'], 
        $formData['Other_Service_No'], $formData['Medals'], $formData['Enlistment_date'], 
        $formData['Discharge_date'], $formData['Death_in_service_date'], $formData['Misc_Info_Nroh'], 
        $formData['Cemetery_Memorial'], $formData['Cemetery_Memorial_Ref'], 
        $formData['Cemetery_Memorial_Country'], $formData['Additional_CWGC_info']
    );

    if ($stmt->execute()) {
        return ['success' => true, 'message' => 'Bradford record created successfully!'];
    } else {
        return ['success' => false, 'message' => 'Something went wrong!'];
    }
}

/**
 * Process Bradford record update
 * 
 * @param int $id Bradford record ID
 * @param array $formData Array containing all Bradford record fields
 * @param object $conn Database connection object
 * @return array Result with success status and message
 */
function processBradfordUpdate($id, $formData, $conn) {
    // Validate ID
    if (!filter_var($id, FILTER_VALIDATE_INT)) {
        return ['success' => false, 'message' => 'Invalid Bradford ID!'];
    }
    
    // Validate required fields
    if (empty($formData['Surname']) || empty($formData['Forename'])) {
        return ['success' => false, 'message' => 'Please fill all required fields!'];
    }
    
    // Check if record exists
    $checkSql = "SELECT id FROM bradford_and_surrounding_townships_great_war_roll_of_honour_2025 WHERE id = ?";
    $checkStmt = $conn->prepare($checkSql);
    
    if (!$checkStmt) {
        return ['success' => false, 'message' => 'Database prepare error!'];
    }
    
    $checkStmt->bind_param("i", $id);
    $checkStmt->execute();
    $checkResult = $checkStmt->get_result();
    
    if ($checkResult->num_rows == 0) {
        return ['success' => false, 'message' => 'Bradford record not found!'];
    }
    
    // SQL query to update Bradford record
    $sql = "UPDATE bradford_and_surrounding_townships_great_war_roll_of_honour_2025 
            SET Surname = ?, Forename = ?, Address = ?, `Electoral Ward` = ?, Town = ?, Rank = ?, Regiment = ?, Unit = ?, 
                Company = ?, Age = ?, `Service No` = ?, `Other Regiment` = ?, `Other Unit` = ?, `Other Service No.` = ?, Medals = ?, 
                `Enlistment date` = ?, `Discharge date` = ?, `Death (in service) date` = ?, `Misc Info Nroh` = ?, 
                `Cemetery/Memorial` = ?, `Cemetery/Memorial Ref` = ?, `Cemetery/Memorial Country` = ?, `Additional CWGC info` = ? 
            WHERE id = ?";

    $stmt = $conn->prepare($sql);
    
    if (!$stmt) {
        return ['success' => false, 'message' => 'Database prepare error!'];
    }
    
    $stmt->bind_param("sssssssssssssssssssssssi", 
        $formData['Surname'], $formData['Forename'], $formData['Address'], $formData['Electoral_Ward'], 
        $formData['Town'], $formData['Rank'], $formData['Regiment'], $formData['Unit'], $formData['Company'], 
        $formData['Age'], $formData['Service_No'], $formData['Other_Regiment'], $formData['Other_Unit'], 
        $formData['Other_Service_No'], $formData['Medals'], $formData['Enlistment_date'], 
        $formData['Discharge_date'], $formData['Death_in_service_date'], $formData['Misc_Info_Nroh'], 
        $formData['Cemetery_Memorial'], $formData['Cemetery_Memorial_Ref'], 
        $formData['Cemetery_Memorial_Country'], $formData['Additional_CWGC_info'],
        $id
    );

    if ($stmt->execute()) {
        return ['success' => true, 'message' => 'Bradford record updated successfully!'];
    } else {
        return ['success' => false, 'message' => 'Something went wrong!'];
    }
}

/**
 * Process Bradford record deletion
 * 
 * @param int $id Bradford record ID
 * @param object $conn Database connection object
 * @return array Result with success status and message
 */
function processBradfordDelete($id, $conn) {
    // Validate ID
    if (!filter_var($id, FILTER_VALIDATE_INT)) {
        return ['success' => false, 'message' => 'Invalid Bradford ID!'];
    }
    
    // Check if record exists
    $checkSql = "SELECT id FROM bradford_and_surrounding_townships_great_war_roll_of_honour_2025 WHERE id = ?";
    $checkStmt = $conn->prepare($checkSql);
    
    if (!$checkStmt) {
        return ['success' => false, 'message' => 'Database prepare error!'];
    }
    
    $checkStmt->bind_param("i", $id);
    $checkStmt->execute();
    $checkResult = $checkStmt->get_result();
    
    if ($checkResult->num_rows == 0) {
        return ['success' => false, 'message' => 'Bradford record not found!'];
    }
    
    // SQL query to delete Bradford record
    $sql = "DELETE FROM bradford_and_surrounding_townships_great_war_roll_of_honour_2025 WHERE id = ?";
    $stmt = $conn->prepare($sql);
    
    if (!$stmt) {
        return ['success' => false, 'message' => 'Database prepare error!'];
    }
    
    $stmt->bind_param("i", $id);
    
    if ($stmt->execute()) {
        return ['success' => true, 'message' => 'Bradford record deleted successfully!'];
    } else {
        return ['success' => false, 'message' => 'Something went wrong!'];
    }
}

/**
 * Get Bradford record by ID
 * 
 * @param int $id Bradford record ID
 * @param object $conn Database connection object
 * @return array|null Bradford record data or null if not found
 */
function getBradfordById($id, $conn) {
    // Validate ID
    if (!filter_var($id, FILTER_VALIDATE_INT)) {
        return null;
    }
    
    // SQL query to get Bradford record
    $sql = "SELECT * FROM bradford_and_surrounding_townships_great_war_roll_of_honour_2025 WHERE id = ?";
    $stmt = $conn->prepare($sql);
    
    if (!$stmt) {
        return null;
    }
    
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows == 0) {
        return null;
    }
    
    return $result->fetch_assoc();
}

/**
 * Get all Bradford records with optional limit
 * 
 * @param object $conn Database connection object
 * @param int $limit Optional limit for number of records to return
 * @return array Array of Bradford records
 */
function getAllBradfords($conn, $limit = null) {
    // SQL query to get all Bradford records
    $sql = "SELECT * FROM bradford_and_surrounding_townships_great_war_roll_of_honour_2025 ORDER BY id DESC";
    
    // Add limit if specified
    if ($limit !== null && filter_var($limit, FILTER_VALIDATE_INT)) {
        $sql .= " LIMIT " . $limit;
    }
    
    $stmt = $conn->prepare($sql);
    
    if (!$stmt) {
        return [];
    }
    
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows == 0) {
        return [];
    }
    
    $bradfords = [];
    while ($row = $result->fetch_assoc()) {
        $bradfords[] = $row;
    }
    
    return $bradfords;
}