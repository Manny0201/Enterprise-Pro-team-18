<?php 

include("../includes/init-session.php");                // Start Session
include("../includes/check-if-not-user.php");           // Check if not user

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>People Search</title>
    <?php include("../includes/head-contents.php"); ?>
</head>
<body>

    <?php include("../includes/navbar.php"); ?>

    <div class="container my-5">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="box">
                    <?php include("../includes/messages.php"); ?>
                    <form action="" method="POST">
                        <h3 class="fw-bold text-center">People Search</h3>
                        <hr>                        
                        <div class="my-3">
                            <label>Search</label>
                            <input type="text" class="form-control" name="textSearch" required>
                        </div>
                        <div class="my-3">
                            <input type="submit" class="btn btn-danger btn-lg w-100" name="search" value="Search">
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    
</body>

</html>