<?php 

/* -------------------------------------------------------------------------- */
/*                     Check if user is already logged-in                     */
/* -------------------------------------------------------------------------- */

	if(isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true)
	{

		header("location: ../user/index.php"); exit();
		
	}

?>