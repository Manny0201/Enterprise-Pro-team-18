<?php

/* -------------------------------------------------------------------------- */
/*                          Website's Configurations                          */
/* -------------------------------------------------------------------------- */


// Define constant for website's name
define('WEBSITE_NAME', 'World War 1 Bradford');

?>