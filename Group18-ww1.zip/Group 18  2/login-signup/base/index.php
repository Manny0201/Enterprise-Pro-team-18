<!DOCTYPE html>
<html lang="en">
<head>
    <title>Home</title>
    <?php include("../includes/head-contents.php"); ?>
</head>
<body>

    <?php include("../includes/navbar.php"); ?>

    
    
</body>
</html>