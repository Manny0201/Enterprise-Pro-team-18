/* -------------------------------------------------------------------------- */
/*                                Database File                               */
/* -------------------------------------------------------------------------- */

DROP DATABASE IF EXISTS `login-signup-db`;          -- Removes database if already exists
CREATE DATABASE `login-signup-db`;                  -- creates new database
USE `login-signup-db`;                              -- selects the database for further actions

/* ------------------------------- Users table ------------------------------ */
CREATE TABLE `users` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `username` varchar(255) NOT NULL,
  `email` varchar(255) UNIQUE NOT NULL,
  `role` char(1) NOT NULL DEFAULT 'u',
  `password` varchar(255) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
);


/* -------------------------------------------------------------------------- */
/*                                  Data Dump                                 */
/* -------------------------------------------------------------------------- */


/* ------------------------------- users data ------------------------------- */
INSERT INTO `users` (`id`, `username`, `email`, `role`, `password`)
VALUES
(1, 'John Doe', 'john@example.com', 'u', '$2y$10$Cg/BMCRs5/xlBMQzezxX7eHArHN46rtkX60/64n89/4yvi7f/KKbS'),
(2, 'Jane Smith', 'jane@example.com', 'u', '$2y$10$Cg/BMCRs5/xlBMQzezxX7eHArHN46rtkX60/64n89/4yvi7f/KKbS'),
(3, 'Alice Johnson', 'alice@example.com', 'u', '$2y$10$Cg/BMCRs5/xlBMQzezxX7eHArHN46rtkX60/64n89/4yvi7f/KKbS'),
(4, 'Bob Brown', 'bob@example.com', 'u', '$2y$10$Cg/BMCRs5/xlBMQzezxX7eHArHN46rtkX60/64n89/4yvi7f/KKbS'),
(5, 'Carol Davis', 'carol@example.com', 'u', '$2y$10$Cg/BMCRs5/xlBMQzezxX7eHArHN46rtkX60/64n89/4yvi7f/KKbS'),
(6, 'David Miller', 'david@example.com', 'u', '$2y$10$Cg/BMCRs5/xlBMQzezxX7eHArHN46rtkX60/64n89/4yvi7f/KKbS'),
(7, 'Eva Wilson', 'eva@example.com', 'u', '$2y$10$Cg/BMCRs5/xlBMQzezxX7eHArHN46rtkX60/64n89/4yvi7f/KKbS'),
(8, 'Frank Moore', 'frank@example.com', 'u', '$2y$10$Cg/BMCRs5/xlBMQzezxX7eHArHN46rtkX60/64n89/4yvi7f/KKbS'),
(9, 'Grace Taylor', 'grace@example.com', 'u', '$2y$10$Cg/BMCRs5/xlBMQzezxX7eHArHN46rtkX60/64n89/4yvi7f/KKbS'),
(10, 'Henry Kent', 'henry@example.com', 'u', '$2y$10$Cg/BMCRs5/xlBMQzezxX7eHArHN46rtkX60/64n89/4yvi7f/KKbS');